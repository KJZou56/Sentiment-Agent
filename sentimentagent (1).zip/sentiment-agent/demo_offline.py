#!/usr/bin/env python3
"""Offline demo — runs the full scoring and reporting path with no network.

Replays four real setups from the Aug 7 2026 tape so you can see the output
format and verify the guards fire before pointing it at live data:

  RKLB  clean signal      chatter accelerating off a dated catalyst, tape agrees
  HTZ   crowded           loudest ticker on the board, already ripped
  SNDK  signal conflict   bullish-looking chatter spike on a stock that fell
  TTD   capitulation      right direction, but it already gapped -28%
  MU    modest long
  YJ    excluded          low-float pump name, filtered on liquidity

  python demo_offline.py
"""
import time

from agent import report
from agent.config import DEFAULTS
from agent.score import Signals, rank, score_ticker

SCORING = DEFAULTS["scoring"]

SETUPS = [
    Signals(
        ticker="RKLB",
        social_mean=0.55, social_agreement=0.80, n_posts=118,
        mention_count=260, mention_baseline_mean=90.0,
        mention_baseline_stdev=40.0, mention_baseline_n=10,
        st_tagged_ratio=0.74, st_n_tagged=30,
        news_mean=0.60, n_headlines=11, has_catalyst=True,
        price=42.0, ret_1d=8.1, ret_5d=12.0, rvol=3.4,
        market_cap=21e9, dollar_volume=4.2e8,
        sources_present=["reddit", "stocktwits", "news"],
    ),
    Signals(
        ticker="HTZ",
        social_mean=0.66, social_agreement=0.85, n_posts=640,
        mention_count=1950, mention_baseline_mean=60.0,
        mention_baseline_stdev=30.0, mention_baseline_n=14,
        st_tagged_ratio=0.80, st_n_tagged=60,
        news_mean=0.45, n_headlines=15, has_catalyst=True,
        price=2.21, ret_1d=17.0, ret_5d=29.0, rvol=8.0,
        market_cap=7.0e8, dollar_volume=9.0e7, short_pct_float=73.85,
        sources_present=["reddit", "stocktwits", "news"],
    ),
    Signals(
        ticker="SNDK",
        social_mean=0.42, social_agreement=0.72, n_posts=210,
        mention_count=340, mention_baseline_mean=100.0,
        mention_baseline_stdev=35.0, mention_baseline_n=12,
        st_tagged_ratio=0.68, st_n_tagged=25,
        news_mean=-0.15, n_headlines=14, has_catalyst=True,
        price=180.0, ret_1d=-5.0, ret_5d=-3.0, rvol=2.6,
        market_cap=2.6e10, dollar_volume=1.1e9,
        sources_present=["reddit", "stocktwits", "news"],
    ),
    Signals(
        ticker="TTD",
        social_mean=-0.70, social_agreement=0.88, n_posts=305,
        mention_count=400, mention_baseline_mean=110.0,
        mention_baseline_stdev=45.0, mention_baseline_n=12,
        st_tagged_ratio=0.12, st_n_tagged=45,
        news_mean=-0.65, n_headlines=15, has_catalyst=True,
        price=38.0, ret_1d=-28.3, ret_5d=-31.0, rvol=6.0,
        market_cap=1.9e10, dollar_volume=1.4e9,
        sources_present=["reddit", "stocktwits", "news"],
    ),
    Signals(
        ticker="MU",
        social_mean=0.44, social_agreement=0.74, n_posts=190,
        mention_count=227, mention_baseline_mean=150.0,
        mention_baseline_stdev=40.0, mention_baseline_n=15,
        st_tagged_ratio=0.69, st_n_tagged=38,
        news_mean=0.30, n_headlines=13, has_catalyst=True,
        price=142.0, ret_1d=2.1, ret_5d=6.4, rvol=1.4,
        market_cap=1.6e11, dollar_volume=2.2e9,
        sources_present=["reddit", "stocktwits", "news"],
    ),
    Signals(
        ticker="YJ",
        social_mean=0.90, social_agreement=0.95, n_posts=40,
        excluded_reason="market cap $41M < $300M",
    ),
]


def main() -> None:
    started = time.time()
    results = [score_ticker(s, SCORING) for s in SETUPS]
    scan = {
        "started": started,
        "elapsed": time.time() - started,
        "candidates": [s.ticker for s in SETUPS],
        "results": results,
        "buckets": rank(results, min_abs_score=2.0, top_n=10),
    }
    report.print_console(scan)
    print(f"\nHTML  -> {report.write_html(scan, './reports')}")
    print(f"JSON  -> {report.write_json(scan, './reports')}")
    print("\nNo network was used. Run `python run.py doctor` to check live sources.")


if __name__ == "__main__":
    main()
