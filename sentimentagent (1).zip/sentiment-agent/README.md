# Sentiment Agent

A stock research agent that ranks buy/sell candidates from **real-time market
sentiment** — social chatter, explicit bull/bear tags, and news flow — rather
than company fundamentals.

**This is a research tool, not advice.** Sentiment signals decay fast and are
heavily front-run by faster participants. Every call it makes shows its
evidence and its warning flags so you are judging the reasoning, not the
verdict. Nothing here is a recommendation to trade.

---

## Quick start

```bash
pip install -r requirements.txt
cp config.example.yaml config.yaml

python demo_offline.py     # see the output format, no network needed
python run.py doctor       # check your install and connectivity
python run.py scan         # first live scan
```

No API keys are required. Everything works out of the box against free,
keyless endpoints. Optional keys only raise rate limits.

---

## Commands

| Command | What it does |
|---|---|
| `python run.py doctor` | Verifies packages, config, and each live data source. Run this first. |
| `python run.py scan` | One scan now. Prints a table, writes HTML + JSON to `./reports`. |
| `python run.py watch` | Polls on a loop. Skips closed markets by default. |
| `python run.py review` | Grades past calls on forward returns. **Read this before trusting it.** |
| `python demo_offline.py` | Replays four real setups offline so you can see output shape. |

---

## What it actually does

**1. Discover** — pulls r/wallstreetbets, r/stocks, r/investing, r/stockmarket
plus StockTwits trending, and extracts tickers.

**2. Gather** — for each candidate: social posts and their engagement weights,
StockTwits' explicit user-applied Bullish/Bearish tags, recent headlines, and
price/volume/short-interest from the tape.

**3. Score** — blends three sentiment channels, weights them by conviction,
then checks the result against the tape and applies four guards.

**4. Rank** — into `LEAN LONG`, `LEAN SHORT`, `CROWDED`, and `SIGNAL CONFLICT`
buckets. The last two are surfaced, not hidden — they are the interesting cases.

**5. Journal** — every call is written to SQLite with the price at the time, so
`review` can grade it later.

---

## The guards

These are the whole point. Without them this is a noise amplifier that buys
tops. Each one exists because of a specific, observed failure:

**`SIGNAL_CONFLICT` — chatter direction disagrees with price direction.**
A stock beats earnings, guides down, and falls 5%. Mentions spike 70% and a
vendor tags the sentiment "Bullish" — because people are *discussing a drop*.
A volume-ranked bot buys it on the day it sells off. When sentiment and tape
disagree materially, the score is cut to 35% and the name is flagged, not ranked.

**`CROWDED` — already ran hard AND maxing out chatter velocity.**
Sentiment peaks at the *end* of moves. The loudest ticker on the board is
usually the most dangerous one — a $2 stock up 29% on the week with 73% of its
float short is mechanical covering, and mechanical moves end when covering ends.
Crowded names get capped at `LEAN`, never promoted.

**`CAPITULATION` — the symmetric short guard.**
After a -28% gap the easy money is gone and bounces off washed-out lows are
violent. Direction can be right while the entry is terrible. Floored, not chased.

**Liquidity exclusion.** Names under $1.50, $300M market cap, or $5M daily
dollar volume are dropped entirely. These dominate raw % gainer lists and are
where manipulation concentrates. A sentiment tool that doesn't exclude them is
mostly a pump detector.

Plus: **velocity is measured against each ticker's own baseline**, stored in
SQLite. Absolute mention counts are meaningless across tickers — SPY always has
hundreds. A stock that normally gets 3 mentions and today has 60 is the signal.

---

## The sentiment engine

Off-the-shelf VADER is trained on general English and is badly wrong here. It
reads "puts" as neutral and has no idea what a bagholder is. Two layers fix it:

- **A finance lexicon** (~200 terms) covering positions, moves, fundamentals
  language, and slang, plus emoji.
- **Phrase rules applied before scoring.** `"shorts are getting rekt"` is three
  negative words and one of the most bullish sentences on the site — somebody
  *else* is losing money. Word-level scoring cannot recover that, so the phrase
  is rewritten first. Same for `calls printing`, `holding the bag`,
  `dead cat bounce`, `diamond hands`.

Set `sentiment.engine: finbert` in config for a finance-tuned transformer
instead. Better on headline-style text, roughly 100x slower, needs
`transformers` + `torch`.

---

## Find out whether it works

This matters more than any feature. Every actionable call is journalled with
the price at the time. After a day or two:

```bash
python run.py review
```

```
Scorecard
  38 settled calls · hit rate 55% · avg signed return +0.41% · median +0.12%
  best +14.2% · worst -9.8% · a coin flip is 50% — treat anything near that as no edge.
```

It grades itself honestly, including the cases it got wrong. If the hit rate
sits near 50% across a few hundred calls, the signal isn't there — and you
should know that rather than assume it.

---

## Configuration

Everything lives in `config.yaml`; see `config.example.yaml` for the annotated
version. Most-used knobs:

```yaml
universe:
  mode: chatter          # chatter | watchlist | both
  watchlist: [NVDA, MU, RKLB]
  max_candidates: 25

scoring:
  divergence: {enabled: true, min_move_pct: 3.0, penalty: 0.35}
  crowding:   {enabled: true, run_pct_5d: 25.0, score_cap: 3.0}

watch:
  interval_seconds: 900  # below ~300 you will hit rate limits
```

Weights under `scoring.weights` and `scoring.conviction` must each sum to 1.0 —
`doctor` checks this and tells you if they don't.

### Optional Reddit credentials

Keyless JSON endpoints work but Reddit throttles hard. For higher limits, make
a free "script" app at <https://www.reddit.com/prefs/apps> and fill in
`sources.reddit.client_id` / `client_secret`, then `pip install praw`.

---

## Run it on a schedule, read it on your phone

Included: a GitHub Actions workflow that scans on a cron, publishes a
mobile-first page to GitHub Pages, and **only interrupts you when a name clears
the score threshold**.

### Setup (about five minutes, once)

1. Push this project to a GitHub repo.
2. **Settings → Actions → General → Workflow permissions** → select
   *Read and write permissions*.
3. **Settings → Pages** → Source: *Deploy from a branch* → Branch: `gh-pages`,
   folder `/`. (The branch appears after the first successful run — run the
   workflow once from the Actions tab first, via *Run workflow*.)
4. Bookmark `https://<you>.github.io/<repo>/` on your phone.

That page always shows the latest scan, the current signal, and an archive of
past runs. Nothing to install, nothing to keep awake.

### Alerts

When a call clears `NOTIFY_MIN_SCORE` (default `5.0`) the workflow opens a
GitHub Issue containing the ticker, the numbers, the flags and the full
reasoning. The GitHub mobile app pushes that to your phone; so does email if
you'd rather not install it.

A name fires **once** while it stays on the board, and can fire again only if
it drops off and later returns. Re-pinging hourly for the same ticker would
train you to ignore the alerts, which defeats the point.

`CROWDED` and `SIGNAL CONFLICT` names never alert. They're on the page to read,
but they are precisely the cases the guards distrust.

**Optional real push without the GitHub app:** add a repo secret `NTFY_TOPIC`
set to any unguessable string, then subscribe to that topic in the free
[ntfy](https://ntfy.sh) app. Leave the secret unset and the step is skipped.

### Tuning

| Knob | Where | Default |
|---|---|---|
| How often it scans | `cron` in `.github/workflows/scan.yml` | hourly, 14:00–21:00 UTC, Mon–Fri |
| Alert threshold | `NOTIFY_MIN_SCORE` in the workflow `env` | `5.0` |
| Everything else | `config.example.yaml` (CI copies it to `config.yaml`) | — |

### Things that will bite you

- **GitHub disables scheduled workflows after 60 days of repo inactivity.**
  This one pushes to `gh-pages` on every run, which counts as activity, so it
  keeps itself alive. If you ever fork it and leave it idle, that resets.
- **Cron times are UTC and GitHub delays runs under load.** Treat the schedule
  as "about hourly," not exact. US market hours also shift an hour between EDT
  and EST — adjust the cron in November and March if you care about the edges.
- **Mention baselines live in `agent_state.db`**, which rides along on the
  `gh-pages` branch. If it's ever lost, velocity falls back to neutral and
  scores carry a `NO_BASELINE` flag until history rebuilds — degraded, not broken.
- **Public repo = public reports.** Use a private repo if you'd rather your
  watchlist not be world-readable. Pages on private repos needs a paid plan;
  alternatively drop the Pages step and just read the Issues.

---

## Tests

```bash
python -m pytest tests/ -q     # 63 tests
```

The suite replays real setups — the divergence trap, the crowded squeeze, the
clean catalyst, the capitulation gap — so if a guard regresses, a test fails.
Two genuine semantic bugs were caught this way during development.

---

## Layout

```
run.py              CLI: doctor / scan / watch / review
demo_offline.py     offline replay, no network
ci/publish.py       builds the phone page, decides whether to alert
.github/workflows/  scheduled scan, Pages deploy, alert-on-signal
agent/
  config.py         defaults + validation
  store.py          SQLite: mention history, call journal, scorecard
  sentiment.py      finance lexicon, phrase rules, VADER/FinBERT
  tickers.py        extraction with false-positive blacklist
  score.py          the rubric and the guards (pure, fully unit-tested)
  scanner.py        orchestration
  report.py         console / HTML / JSON
  sources/          stocktwits, reddit, news, prices
tests/              54 tests
```

`score.py` is deliberately pure — no network, no I/O — so the entire decision
model is testable offline. If you want to change how it thinks, that's the file.

---

## Limits worth knowing

- **Not real-time to the tick.** Poll cadence is minutes. If you need
  sub-second, this is the wrong architecture.
- **Sentiment is a crowding indicator as much as a direction one.** It tells
  you what's being talked about; the guards exist because that's often the
  opposite of what you want to buy.
- **Free endpoints throttle.** Below ~300s intervals you'll get rate limited.
- **Ticker extraction is imperfect.** `CEO`, `DD`, `ATH` are all real symbols.
  The blacklist catches the common ones; odd cases will slip through.
- **Reddit blocks generic user agents.** Keep a descriptive one in config.

---

*Not investment advice. No warranty. You are responsible for your own trades.*
