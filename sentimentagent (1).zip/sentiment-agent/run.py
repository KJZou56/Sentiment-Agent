#!/usr/bin/env python3
"""Sentiment-driven stock research agent.

  python run.py doctor            check your install and connectivity
  python run.py scan              one scan now, print + write reports
  python run.py watch             poll on a loop
  python run.py review            grade past calls on forward returns

Not investment advice. Sentiment signals decay fast and are heavily front-run.
"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from datetime import datetime, timedelta, timezone

from agent import config as config_mod
from agent import report
from agent.store import Store


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )
    for noisy in ("urllib3", "yfinance", "peewee", "requests"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def market_is_open(now_utc: datetime | None = None) -> bool:
    """Rough US equity regular-session check (weekdays 13:30-20:00 UTC).

    Deliberately approximate — it does not know about holidays or DST edge
    cases. It exists to stop the watch loop burning rate limits overnight, not
    to be a trading calendar.
    """
    now = now_utc or datetime.now(timezone.utc)
    if now.weekday() >= 5:
        return False
    minutes = now.hour * 60 + now.minute
    return 13 * 60 + 30 <= minutes <= 20 * 60


def cmd_doctor(args) -> int:
    print("Checking install...\n")
    ok = True

    for mod, why in [
        ("yfinance", "prices/volume"), ("requests", "StockTwits + Reddit"),
        ("feedparser", "news RSS"), ("vaderSentiment", "sentiment"),
        ("yaml", "config"), ("rich", "console output"),
    ]:
        try:
            __import__(mod)
            print(f"  ok      {mod:<16} ({why})")
        except ImportError:
            ok = False
            print(f"  MISSING {mod:<16} ({why})  -> pip install -r requirements.txt")

    for mod, why in [("praw", "authenticated Reddit"), ("transformers", "FinBERT")]:
        try:
            __import__(mod)
            print(f"  ok      {mod:<16} (optional: {why})")
        except ImportError:
            print(f"  --      {mod:<16} (optional: {why}, not installed)")

    if not ok:
        print("\nInstall the missing packages first.")
        return 1

    cfg = config_mod.load(args.config)
    problems = cfg.validate()
    if problems:
        print("\nConfig problems:")
        for p in problems:
            print(f"  - {p}")
        return 1
    print("\n  ok      config validates")

    print("\nChecking connectivity (this hits the network)...")
    try:
        from agent.sources.prices import PriceSource
        q = PriceSource().quote("AAPL")
        print(f"  ok      yfinance      AAPL ${q['price']:.2f} ({q['ret_1d']:+.2f}%)"
              if q else "  FAIL    yfinance      no data for AAPL")
        ok = ok and q is not None
    except Exception as exc:
        ok = False
        print(f"  FAIL    yfinance      {exc}")

    try:
        from agent.sources.stocktwits import StockTwitsSource
        tr = StockTwitsSource().trending(limit=5)
        print(f"  ok      stocktwits    trending: {', '.join(tr)}" if tr
              else "  WARN    stocktwits    reachable but returned nothing")
    except Exception as exc:
        print(f"  WARN    stocktwits    {exc}")

    try:
        from agent.sources.reddit import RedditSource
        rs = RedditSource(subreddits=["stocks"], posts_per_sub=5,
                          include_comments=False,
                          user_agent=cfg.get("sources.reddit.user_agent"))
        docs = rs._fetch_keyless("stocks")
        print(f"  ok      reddit        {len(docs)} posts from r/stocks" if docs
              else "  WARN    reddit        blocked or empty — set a descriptive "
                   "user_agent, or add PRAW credentials")
    except Exception as exc:
        print(f"  WARN    reddit        {exc}")

    try:
        from agent.sources.news import NewsSource
        nw = NewsSource(max_headlines=3).fetch("AAPL")
        print(f"  ok      news          {len(nw['items'])} headlines for AAPL"
              if nw["items"] else "  WARN    news          no headlines returned")
    except Exception as exc:
        print(f"  WARN    news          {exc}")

    print("\nWARN lines are survivable — the agent drops that source and "
          "renormalises the remaining weights.")
    print("Ready." if ok else "\nFix the FAIL lines before scanning.")
    return 0 if ok else 1


def cmd_scan(args) -> int:
    from agent.scanner import Scanner

    cfg = config_mod.load(args.config)
    problems = cfg.validate()
    if problems:
        for p in problems:
            print(f"config error: {p}", file=sys.stderr)
        return 1

    store = Store(args.db)
    try:
        scan = Scanner(cfg, store).scan()
        report.print_console(scan)
        out_dir = cfg.get("output.dir", "./reports")
        if cfg.get("output.html", True):
            print(f"\nHTML  -> {report.write_html(scan, out_dir)}")
        if cfg.get("output.json", True):
            print(f"JSON  -> {report.write_json(scan, out_dir)}")
    finally:
        store.close()
    return 0


def cmd_watch(args) -> int:
    from agent.scanner import Scanner

    cfg = config_mod.load(args.config)
    problems = cfg.validate()
    if problems:
        for p in problems:
            print(f"config error: {p}", file=sys.stderr)
        return 1

    interval = args.interval or cfg.get("watch.interval_seconds", 900)
    hours_only = cfg.get("watch.market_hours_only", True)
    store = Store(args.db)
    print(f"Watching every {interval}s. Ctrl-C to stop.\n")

    try:
        while True:
            if hours_only and not market_is_open():
                nxt = datetime.now(timezone.utc) + timedelta(seconds=interval)
                print(f"[{datetime.now().strftime('%H:%M:%S')}] market closed, "
                      f"skipping (next check {nxt.strftime('%H:%M')} UTC)")
                time.sleep(interval)
                continue
            try:
                scan = Scanner(cfg, store).scan()
                report.print_console(scan)
                out_dir = cfg.get("output.dir", "./reports")
                if cfg.get("output.html", True):
                    report.write_html(scan, out_dir)
                if cfg.get("output.json", True):
                    report.write_json(scan, out_dir)
            except Exception as exc:
                logging.exception("scan failed, continuing: %s", exc)
            time.sleep(interval)
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        store.close()
    return 0


def cmd_review(args) -> int:
    from agent.sources.prices import PriceSource

    store = Store(args.db)
    try:
        pending = store.unreviewed_calls(older_than_hours=args.after_hours)
        if pending:
            print(f"Settling {len(pending)} call(s) older than "
                  f"{args.after_hours}h...\n")
            prices = PriceSource()
            for row in pending:
                spot = prices.price_now(row["ticker"])
                if spot is None:
                    print(f"  {row['ticker']:<6} could not price, skipping")
                    continue
                out = store.settle_call(row["id"], spot)
                if out:
                    mark = "hit " if out["correct"] else "miss"
                    print(f"  {out['ticker']:<6} {out['label']:<13} "
                          f"{out['return_pct']:+6.2f}%  {mark}")
            print()
        report.print_scorecard(store.scorecard())
    finally:
        store.close()
    return 0


def main() -> int:
    p = argparse.ArgumentParser(
        description="Sentiment-driven stock research agent (not advice)"
    )
    p.add_argument("-c", "--config", default="config.yaml")
    p.add_argument("--db", default="agent_state.db")
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("doctor", help="check install and connectivity")
    sub.add_parser("scan", help="run one scan now")

    w = sub.add_parser("watch", help="poll on a loop")
    w.add_argument("--interval", type=int, default=None, help="seconds")

    r = sub.add_parser("review", help="grade past calls on forward returns")
    r.add_argument("--after-hours", type=float, default=24.0,
                   help="only settle calls at least this old (default 24)")

    args = p.parse_args()
    _setup_logging(args.verbose)

    return {
        "doctor": cmd_doctor, "scan": cmd_scan,
        "watch": cmd_watch, "review": cmd_review,
    }[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
