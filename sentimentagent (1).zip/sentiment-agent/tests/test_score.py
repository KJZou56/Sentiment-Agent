"""Replays of real setups from the Aug 7 2026 tape.

Each test encodes a way this class of tool goes wrong. If a guard regresses,
one of these fails.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from agent.config import DEFAULTS
from agent.score import (LEAN, STRONG, Signals, label_for, rank, score_ticker,
                         velocity)

SCORING = DEFAULTS["scoring"]


def base_signals(**kw) -> Signals:
    defaults = dict(
        ticker="TEST",
        social_mean=0.0, social_agreement=0.5, n_posts=50,
        mention_count=100, mention_baseline_mean=100.0,
        mention_baseline_stdev=20.0, mention_baseline_n=10,
        st_tagged_ratio=None, st_n_tagged=0,
        news_mean=0.0, n_headlines=5, has_catalyst=False,
        price=50.0, ret_1d=0.0, ret_5d=0.0, rvol=1.0,
        market_cap=5e9, dollar_volume=1e8,
        sources_present=["reddit", "stocktwits", "news"],
    )
    defaults.update(kw)
    return Signals(**defaults)


# --------------------------------------------------------------------------
# SNDK: the divergence trap. Beat on earnings, guided down, fell 5%. Mention
# volume spiked and one vendor tagged it "Bullish". A volume-ranked bot buys
# this on the day it sells off.
# --------------------------------------------------------------------------

def test_sndk_divergence_is_caught():
    sig = base_signals(
        ticker="SNDK",
        social_mean=0.42,            # chatter reads bullish
        social_agreement=0.72,
        st_tagged_ratio=0.68, st_n_tagged=25,
        news_mean=-0.15, has_catalyst=True,
        mention_count=340,           # big spike vs baseline 100
        ret_1d=-5.0,                 # ...but the tape went the other way
        ret_5d=-3.0,
        price=180.0,
    )
    res = score_ticker(sig, SCORING)
    assert "SIGNAL_CONFLICT" in res.flags
    assert res.label == "CONFLICT"
    assert res.score < 3.0, "conflicted signal must not read as a buy"
    assert any("CONFLICT" in line for line in res.rationale)


def test_divergence_not_triggered_on_small_moves():
    """A 1% wiggle is noise, not disagreement — the guard must not overfire."""
    sig = base_signals(social_mean=0.5, social_agreement=0.8, ret_1d=-1.0)
    res = score_ticker(sig, SCORING)
    assert "SIGNAL_CONFLICT" not in res.flags


# --------------------------------------------------------------------------
# HTZ: loudest ticker on the board by ~3x, real earnings beat, 73% of float
# short, already ripped. Loud does not mean early.
# --------------------------------------------------------------------------

def test_htz_crowding_caps_the_score():
    sig = base_signals(
        ticker="HTZ",
        social_mean=0.66, social_agreement=0.85,
        st_tagged_ratio=0.80, st_n_tagged=60,
        news_mean=0.45, has_catalyst=True,
        mention_count=1950, mention_baseline_mean=60.0,
        mention_baseline_stdev=30.0, mention_baseline_n=14,
        ret_1d=17.0, ret_5d=29.0,
        price=2.21, rvol=8.0, short_pct_float=73.85,
        market_cap=700e6,
    )
    res = score_ticker(sig, SCORING)
    assert "CROWDED" in res.flags
    assert res.score <= SCORING["crowding"]["score_cap"]
    assert "HIGH_SHORT_INTEREST" in res.flags
    assert any("CROWDED" in line for line in res.rationale)
    # Crowded names must not be presented as clean longs.
    buckets = rank([res])
    assert res not in buckets["long"]
    assert res in buckets["crowded"]


def test_uncrowded_strong_signal_still_scores_high():
    """The crowding guard must not flatten every good signal."""
    sig = base_signals(
        social_mean=0.62, social_agreement=0.86,
        st_tagged_ratio=0.78, st_n_tagged=40,
        news_mean=0.5, has_catalyst=True,
        mention_count=300, mention_baseline_mean=100.0,
        mention_baseline_stdev=25.0, mention_baseline_n=12,
        ret_1d=4.0, ret_5d=6.0,      # moved, but has not run away
    )
    res = score_ticker(sig, SCORING)
    assert "CROWDED" not in res.flags
    assert res.score > 4.0
    assert res.label in ("LEAN LONG", "STRONG LONG")


# --------------------------------------------------------------------------
# RKLB: chatter accelerating off a dated, checkable catalyst, tape agrees.
# This is the shape the tool should reward.
# --------------------------------------------------------------------------

def test_rklb_catalyst_and_price_confirmation():
    sig = base_signals(
        ticker="RKLB",
        social_mean=0.55, social_agreement=0.80,
        st_tagged_ratio=0.74, st_n_tagged=30,
        news_mean=0.6, has_catalyst=True,
        mention_count=260, mention_baseline_mean=90.0,
        mention_baseline_stdev=40.0, mention_baseline_n=10,
        ret_1d=8.1, ret_5d=12.0,
        price=42.0, rvol=3.4,
    )
    res = score_ticker(sig, SCORING)
    assert "PRICE_CONFIRMED" in res.flags
    assert "HARD_CATALYST" in res.flags
    assert "VOLUME_SPIKE" in res.flags
    assert res.score > 4.0
    assert rank([res])["long"] == [res]


def test_no_catalyst_is_flagged():
    sig = base_signals(social_mean=0.55, social_agreement=0.8,
                       has_catalyst=False, n_headlines=8)
    res = score_ticker(sig, SCORING)
    assert "NO_CATALYST" in res.flags


# --------------------------------------------------------------------------
# TTD: -28% gap to a 7-year low. Direction was right; chasing it is not.
# --------------------------------------------------------------------------

def test_ttd_capitulation_floors_the_short():
    sig = base_signals(
        ticker="TTD",
        social_mean=-0.70, social_agreement=0.88,
        st_tagged_ratio=0.12, st_n_tagged=45,
        news_mean=-0.65, has_catalyst=True,
        mention_count=400, mention_baseline_mean=110.0,
        mention_baseline_stdev=45.0, mention_baseline_n=12,
        ret_1d=-28.3, ret_5d=-31.0,
        price=38.0, rvol=6.0,
    )
    res = score_ticker(sig, SCORING)
    assert "CAPITULATION" in res.flags
    assert res.score >= SCORING["capitulation"]["score_floor"]
    assert any("CAPITULATION" in line for line in res.rationale)


def test_short_without_gap_is_not_floored():
    sig = base_signals(
        social_mean=-0.62, social_agreement=0.85,
        st_tagged_ratio=0.15, st_n_tagged=40,
        news_mean=-0.55, has_catalyst=True,
        ret_1d=-4.5, ret_5d=-9.0,
    )
    res = score_ticker(sig, SCORING)
    assert "CAPITULATION" not in res.flags
    assert res.score < -4.0
    assert res.label in ("LEAN SHORT", "STRONG SHORT")


# --------------------------------------------------------------------------
# Velocity: absolute mention counts are meaningless across tickers.
# --------------------------------------------------------------------------

def test_velocity_is_relative_to_own_baseline():
    always_loud = base_signals(mention_count=500, mention_baseline_mean=500.0,
                               mention_baseline_stdev=50.0, mention_baseline_n=20)
    suddenly_loud = base_signals(mention_count=60, mention_baseline_mean=5.0,
                                 mention_baseline_stdev=3.0, mention_baseline_n=20)
    assert velocity(suddenly_loud) > velocity(always_loud)
    assert velocity(always_loud) < 0.2, "SPY-like constant chatter is not a spike"


def test_velocity_neutral_without_history():
    sig = base_signals(mention_baseline_n=0, mention_count=9999)
    assert velocity(sig) == 0.5
    res = score_ticker(sig, SCORING)
    assert "NO_BASELINE" in res.flags


# --------------------------------------------------------------------------
# Liquidity exclusion: the YJ/MB +417% low-float names.
# --------------------------------------------------------------------------

def test_excluded_ticker_scores_zero():
    sig = base_signals(ticker="YJ", social_mean=0.9, social_agreement=0.95,
                       excluded_reason="market cap $40M < $300M")
    res = score_ticker(sig, SCORING)
    assert res.label == "EXCLUDED"
    assert res.score == 0.0
    assert rank([res])["long"] == []


# --------------------------------------------------------------------------
# Blending mechanics.
# --------------------------------------------------------------------------

def test_missing_stocktwits_does_not_drag_toward_zero():
    """A ticker with no StockTwits coverage must not be penalised for it."""
    with_st = base_signals(social_mean=0.6, social_agreement=0.8,
                           st_tagged_ratio=0.80, st_n_tagged=20, news_mean=0.6)
    without_st = base_signals(social_mean=0.6, social_agreement=0.8,
                              st_tagged_ratio=None, st_n_tagged=0, news_mean=0.6,
                              sources_present=["reddit", "news"])
    a = score_ticker(with_st, SCORING)
    b = score_ticker(without_st, SCORING)
    # b loses some corroboration credit, but its *direction* must survive.
    assert b.score > 3.0
    assert abs(a.score - b.score) < 2.5


def test_thinly_tagged_stocktwits_is_ignored():
    """Two bullish tags is not a sentiment reading."""
    sig = base_signals(social_mean=0.0, social_agreement=0.5,
                       st_tagged_ratio=1.0, st_n_tagged=2, news_mean=0.0)
    res = score_ticker(sig, SCORING)
    assert abs(res.score) < 1.0


def test_score_stays_in_bounds():
    extreme = base_signals(
        social_mean=1.0, social_agreement=1.0,
        st_tagged_ratio=1.0, st_n_tagged=200, news_mean=1.0,
        has_catalyst=True, mention_count=99999,
        mention_baseline_mean=10.0, mention_baseline_stdev=2.0,
        mention_baseline_n=30, ret_1d=9.0, ret_5d=10.0,
    )
    assert -10.0 <= score_ticker(extreme, SCORING).score <= 10.0


def test_labels_map_correctly():
    assert label_for(7.0, []) == "STRONG LONG"
    assert label_for(4.0, []) == "LEAN LONG"
    assert label_for(0.0, []) == "NEUTRAL"
    assert label_for(-4.0, []) == "LEAN SHORT"
    assert label_for(-8.0, []) == "STRONG SHORT"
    assert label_for(8.0, ["SIGNAL_CONFLICT"]) == "CONFLICT"
    assert label_for(3.0, ["CROWDED"]) == "CROWDED LONG"
    assert label_for(-3.0, ["CROWDED"]) == "CROWDED SHORT"


def test_label_boundaries_are_symmetric():
    """+3.0 is LEAN LONG, so -3.0 must be LEAN SHORT. An earlier version
    returned NEUTRAL at exactly -3.0 while still ranking it as a short."""
    assert label_for(LEAN, []) == "LEAN LONG"
    assert label_for(-LEAN, []) == "LEAN SHORT"
    assert label_for(STRONG, []) == "STRONG LONG"
    assert label_for(-STRONG, []) == "STRONG SHORT"


def test_capitulation_floor_still_labels_as_short():
    """The floored TTD case must not come out labelled NEUTRAL."""
    sig = base_signals(
        social_mean=-0.70, social_agreement=0.88,
        st_tagged_ratio=0.12, st_n_tagged=45,
        news_mean=-0.65, has_catalyst=True,
        ret_1d=-28.3, ret_5d=-31.0,
    )
    res = score_ticker(sig, SCORING)
    assert res.label == "LEAN SHORT"
    assert res in rank([res])["short"]


def test_neutral_signal_produces_no_calls():
    """Most of the time there is nothing to do, and it must say so."""
    quiet = [base_signals(ticker=f"T{i}", social_mean=0.05,
                          social_agreement=0.52) for i in range(5)]
    buckets = rank([score_ticker(s, SCORING) for s in quiet])
    assert buckets["long"] == []
    assert buckets["short"] == []
