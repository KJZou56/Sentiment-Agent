import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest

from agent.sentiment import SentimentEngine, clean, has_catalyst
from agent.tickers import TickerExtractor


@pytest.fixture(scope="module")
def eng():
    return SentimentEngine("vader")


# --- the whole point of the finance lexicon -------------------------------

@pytest.mark.parametrize("bullish,bearish", [
    ("loaded up on calls, this thing is ripping",
     "loaded up on puts, this thing is tanking"),
    ("earnings beat, guidance raised, upgraded by three analysts",
     "earnings miss, guidance lowered, downgraded by three analysts"),
    ("squeeze is on, shorts are getting rekt",
     "dilution incoming, bagholders getting rekt"),
])
def test_direction_is_correct(eng, bullish, bearish):
    assert eng.score(bullish) > 0.2
    assert eng.score(bearish) < -0.2
    assert eng.score(bullish) > eng.score(bearish)


def test_plain_vader_would_miss_this(eng):
    """'puts' is invisible to stock VADER; here it must read clearly bearish."""
    assert eng.score("bought puts") < -0.1
    assert eng.score("bought calls") > 0.1


def test_emoji_carry_signal(eng):
    assert eng.score("NVDA \U0001F680\U0001F680\U0001F680") > 0.3
    assert eng.score("NVDA \U0001F4C9\U0001F480") < -0.2


def test_neutral_text_is_neutral(eng):
    assert abs(eng.score("The company will report on Tuesday.")) < 0.3


# --- phrase rules: where plain bag-of-words inverts ------------------------

@pytest.mark.parametrize("text", [
    "shorts are getting rekt",
    "shorts getting squeezed",
    "bears are so cooked",
    "short squeeze is on",
    "shorts covering hard",
    "calls printing",
    "diamond hands to the moon",
])
def test_someone_elses_pain_reads_bullish(eng, text):
    """Three negative words that add up to a bullish sentence."""
    assert eng.score(text) > 0.2, f"{text!r} scored {eng.score(text)}"


@pytest.mark.parametrize("text", [
    "bulls are getting rekt",
    "longs got destroyed",
    "puts printing",
    "everyone holding the bag",
    "catching a falling knife here",
    "classic dead cat bounce",
])
def test_our_side_hurting_reads_bearish(eng, text):
    assert eng.score(text) < -0.2, f"{text!r} scored {eng.score(text)}"


def test_phrase_rules_do_not_invert_genuine_bearishness(eng):
    """The rewrite must not turn real bad news bullish."""
    assert eng.score("dilution incoming, bagholders getting rekt") < -0.2
    assert eng.score("shorts were right, this is bankrupt") < -0.2


def test_clean_strips_urls_and_cashtags():
    out = clean("check $NVDA https://example.com/x now")
    assert "http" not in out
    assert "NVDA" in out and "$NVDA" not in out


# --- aggregation ----------------------------------------------------------

def test_agreement_detects_a_split_room(eng):
    united = eng.score_many(["calls printing", "mooning", "squeeze incoming",
                             "loading more"])
    split = eng.score_many(["calls printing", "puts printing",
                            "this is going to crash", "mooning"])
    assert united["agreement"] > split["agreement"]
    assert united["agreement"] > 0.9


def test_weights_shift_the_mean(eng):
    texts = ["absolutely mooning, calls printing", "this is going to crash hard"]
    bull_heavy = eng.score_many(texts, [10.0, 1.0])
    bear_heavy = eng.score_many(texts, [1.0, 10.0])
    assert bull_heavy["mean"] > bear_heavy["mean"]


def test_empty_input_is_safe(eng):
    agg = eng.score_many([])
    assert agg["n"] == 0 and agg["mean"] == 0.0 and agg["agreement"] == 0.5


# --- catalyst detection ---------------------------------------------------

@pytest.mark.parametrize("text", [
    "Rocket Lab awarded $397 million Space Force contract",
    "Q2 earnings beat expectations",
    "FDA approval granted for phase 3 trial",
    "Company announces buyback and dividend",
])
def test_catalyst_detected(text):
    assert has_catalyst(text)


@pytest.mark.parametrize("text", [
    "this stock feels like it wants to run",
    "vibes are good here honestly",
    "chart looks clean",
])
def test_vibes_are_not_catalysts(text):
    assert not has_catalyst(text)


# --- ticker extraction ----------------------------------------------------

def test_cashtags_always_extract():
    ex = TickerExtractor()
    assert ex.extract("buying $NVDA and $AMD today") == ["NVDA", "AMD"]


def test_jargon_is_not_a_ticker():
    """CEO, DD, ATH, IMO are all real listed symbols. None are meant here."""
    ex = TickerExtractor()
    text = "The CEO is an idiot, this DD is ATH tier IMO. FDA and SEC agree."
    assert ex.extract(text) == []


def test_bare_tokens_need_validation():
    ex = TickerExtractor()   # no validator supplied
    assert ex.extract("ZXQW is going to run") == []

    ex2 = TickerExtractor(validator=lambda s: {"price": 10.0} if s == "ZXQW" else None)
    assert ex2.extract("ZXQW is going to run") == ["ZXQW"]


def test_known_names_pass_without_a_validator():
    ex = TickerExtractor()
    assert "GME" in ex.extract("GME to the moon")


def test_repeat_mentions_count_once_per_post():
    ex = TickerExtractor()
    counts = ex.count(["$NVDA $NVDA $NVDA is great", "$NVDA ok"])
    assert counts["NVDA"] == 2, "one mention per post, not per occurrence"
