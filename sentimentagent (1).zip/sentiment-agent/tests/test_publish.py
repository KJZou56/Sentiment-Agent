"""Alert de-duplication.

The failure mode here is alert fatigue: re-pinging every hour for the same
ticker trains you to ignore the alerts, which defeats the point of having them.
"""
import json
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from ci.publish import actionable  # noqa: E402


def make_scan(tmp: Path, calls) -> None:
    """Write a minimal scan JSON the publisher can consume."""
    reports = tmp / "reports"
    reports.mkdir(exist_ok=True)
    longs = [c for c in calls if c[1] > 0]
    shorts = [c for c in calls if c[1] < 0]

    def ser(t, s):
        return {
            "ticker": t, "score": s, "label": "LEAN LONG" if s > 0 else "LEAN SHORT",
            "flags": [], "rationale": ["synthetic"], "components": {},
            "market": {"price": 10.0, "ret_1d": 1.0, "ret_5d": 2.0, "rvol": 1.0},
            "social": {},
        }

    existing = sorted(reports.glob("scan-*.json"))
    name = f"scan-2026080{len(existing) + 1}-120000.json"
    (reports / name).write_text(json.dumps({
        "generated_utc": "2026-08-08T12:00:00+00:00",
        "elapsed_seconds": 1.0,
        "candidates": [c[0] for c in calls],
        "buckets": {
            "long": [ser(t, s) for t, s in longs],
            "short": [ser(t, s) for t, s in shorts],
            "crowded": [], "conflict": [], "excluded": [],
        },
    }), encoding="utf-8")
    (reports / name.replace(".json", ".html")).write_text("<html></html>", encoding="utf-8")


def run_publish(tmp: Path, min_score: float = 5.0) -> dict:
    subprocess.run(
        [sys.executable, str(ROOT / "ci" / "publish.py"),
         "--reports", str(tmp / "reports"), "--site", str(tmp / "site"),
         "--min-score", str(min_score), "--signal-out", str(tmp / "signal.json")],
        check=True, capture_output=True, cwd=tmp,
    )
    return json.loads((tmp / "signal.json").read_text())


def test_fires_once_then_stays_quiet(tmp_path):
    make_scan(tmp_path, [("RKLB", 6.6)])
    first = run_publish(tmp_path)
    assert first["notify"] is True
    assert "RKLB" in first["title"]

    second = run_publish(tmp_path)
    assert second["notify"] is False, "same ticker must not re-alert"


def test_new_ticker_fires_even_if_another_is_already_up(tmp_path):
    make_scan(tmp_path, [("RKLB", 6.6)])
    run_publish(tmp_path)
    make_scan(tmp_path, [("RKLB", 6.6), ("MU", 7.1)])
    out = run_publish(tmp_path)
    assert out["notify"] is True
    assert "MU" in out["title"]
    assert "RKLB" not in out["title"], "already-alerted name should not repeat"


def test_ticker_can_realert_after_dropping_off(tmp_path):
    make_scan(tmp_path, [("RKLB", 6.6)])
    assert run_publish(tmp_path)["notify"] is True
    make_scan(tmp_path, [])                       # falls off the board
    assert run_publish(tmp_path)["notify"] is False
    make_scan(tmp_path, [("RKLB", 6.9)])          # comes back later
    assert run_publish(tmp_path)["notify"] is True


def test_below_threshold_never_alerts(tmp_path):
    make_scan(tmp_path, [("MU", 3.6)])
    assert run_publish(tmp_path, min_score=5.0)["notify"] is False


def test_shorts_alert_too(tmp_path):
    make_scan(tmp_path, [("TTD", -6.2)])
    out = run_publish(tmp_path)
    assert out["notify"] is True and "TTD" in out["title"]


def test_index_is_written(tmp_path):
    make_scan(tmp_path, [("RKLB", 6.6)])
    run_publish(tmp_path)
    index = (tmp_path / "site" / "index.html").read_text()
    assert "Sentiment Agent" in index
    assert "RKLB" in index
    assert "not advice" in index.lower()


def test_quiet_scan_renders_without_crashing(tmp_path):
    make_scan(tmp_path, [])
    out = run_publish(tmp_path)
    assert out["notify"] is False
    index = (tmp_path / "site" / "index.html").read_text()
    assert "Nothing cleared the threshold" in index


def test_crowded_and_conflict_never_alert(tmp_path):
    """Those buckets are exactly the cases the guards distrust."""
    reports = tmp_path / "reports"
    reports.mkdir(exist_ok=True)
    (reports / "scan-20260808-120000.json").write_text(json.dumps({
        "generated_utc": "2026-08-08T12:00:00+00:00", "elapsed_seconds": 1.0,
        "candidates": ["HTZ", "SNDK"],
        "buckets": {
            "long": [], "short": [],
            "crowded": [{"ticker": "HTZ", "score": 9.0, "label": "CROWDED LONG",
                         "flags": ["CROWDED"], "rationale": [], "market": {}}],
            "conflict": [{"ticker": "SNDK", "score": 8.0, "label": "CONFLICT",
                          "flags": ["SIGNAL_CONFLICT"], "rationale": [], "market": {}}],
            "excluded": [],
        },
    }), encoding="utf-8")
    (reports / "scan-20260808-120000.html").write_text("<html></html>", encoding="utf-8")
    assert run_publish(tmp_path)["notify"] is False


def test_actionable_filters_by_absolute_score():
    scan = {"buckets": {
        "long": [{"ticker": "A", "score": 6.0}, {"ticker": "B", "score": 2.0}],
        "short": [{"ticker": "C", "score": -7.0}],
    }}
    got = [c["ticker"] for c in actionable(scan, 5.0)]
    assert got == ["C", "A"], "ranked by magnitude, weak names dropped"
