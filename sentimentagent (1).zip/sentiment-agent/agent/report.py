"""Output: console tables, HTML report, JSON."""
from __future__ import annotations

import html as _html
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from .score import Result

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
except ImportError:  # pragma: no cover
    Console = None

BUCKET_TITLES = {
    "long": "LEAN LONG",
    "short": "LEAN SHORT",
    "crowded": "CROWDED — loudest, latest",
    "conflict": "SIGNAL CONFLICT — chatter disagrees with tape",
}
BUCKET_STYLES = {"long": "green", "short": "red", "crowded": "yellow", "conflict": "cyan"}


# ---------------- console ----------------

def print_console(scan: Dict[str, Any]) -> None:
    buckets = scan["buckets"]
    if Console is None:
        _print_plain(buckets)
        return

    con = Console()
    stamp = datetime.fromtimestamp(scan["started"], timezone.utc).strftime(
        "%Y-%m-%d %H:%M UTC"
    )
    con.print(Panel(
        f"[bold]Sentiment scan[/bold] · {stamp} · "
        f"{len(scan['candidates'])} candidates · {scan['elapsed']:.1f}s\n"
        f"[dim]Research signal, not advice. Sentiment decays fast and is "
        f"heavily front-run.[/dim]",
        border_style="blue",
    ))

    for key in ("long", "short", "crowded", "conflict"):
        rows = buckets.get(key) or []
        if not rows:
            continue
        table = Table(title=BUCKET_TITLES[key], title_justify="left",
                      header_style="bold", border_style=BUCKET_STYLES[key])
        table.add_column("Ticker", style="bold")
        table.add_column("Score", justify="right")
        table.add_column("Label")
        table.add_column("1d", justify="right")
        table.add_column("5d", justify="right")
        table.add_column("Posts", justify="right")
        table.add_column("Flags", overflow="fold")
        for r in rows:
            s = r.signals
            table.add_row(
                r.ticker, f"{r.score:+.1f}", r.label,
                f"{s.ret_1d:+.1f}%", f"{s.ret_5d:+.1f}%",
                str(s.n_posts),
                ", ".join(f for f in r.flags if f not in ("NO_BASELINE",)) or "—",
            )
        con.print(table)

    top = (buckets.get("long") or []) + (buckets.get("conflict") or [])
    for r in top[:5]:
        con.print(f"\n[bold]{r.ticker}[/bold] [dim]{r.label} {r.score:+.1f}[/dim]")
        for line in r.rationale:
            con.print(f"  • {line}")

    excluded = buckets.get("excluded") or []
    if excluded:
        names = ", ".join(f"{r.ticker} ({r.components.get('reason','')})"
                          for r in excluded[:8])
        con.print(f"\n[dim]Excluded: {names}[/dim]")


def _print_plain(buckets: Dict[str, List[Result]]) -> None:  # pragma: no cover
    for key in ("long", "short", "crowded", "conflict"):
        rows = buckets.get(key) or []
        if not rows:
            continue
        print(f"\n=== {BUCKET_TITLES[key]} ===")
        for r in rows:
            print(f"{r.ticker:<6} {r.score:+6.1f}  {r.label:<13} "
                  f"1d {r.signals.ret_1d:+6.1f}%  {', '.join(r.flags)}")
            for line in r.rationale:
                print(f"    - {line}")


# ---------------- json ----------------

def to_dict(scan: Dict[str, Any]) -> Dict[str, Any]:
    def ser(r: Result) -> Dict[str, Any]:
        s = r.signals
        return {
            "ticker": r.ticker, "score": r.score, "label": r.label,
            "flags": r.flags, "rationale": r.rationale,
            "components": r.components,
            "market": {
                "price": s.price, "ret_1d": s.ret_1d, "ret_5d": s.ret_5d,
                "rvol": s.rvol, "market_cap": s.market_cap,
                "short_pct_float": s.short_pct_float,
            },
            "social": {
                "mention_count": s.mention_count, "n_posts": s.n_posts,
                "social_mean": s.social_mean, "agreement": s.social_agreement,
                "stocktwits_bull_ratio": s.st_tagged_ratio,
                "n_headlines": s.n_headlines, "has_catalyst": s.has_catalyst,
                "sources": s.sources_present,
            },
        }

    return {
        "generated_utc": datetime.fromtimestamp(
            scan["started"], timezone.utc).isoformat(),
        "elapsed_seconds": round(scan["elapsed"], 2),
        "candidates": scan["candidates"],
        "buckets": {k: [ser(r) for r in v] for k, v in scan["buckets"].items()},
    }


def write_json(scan: Dict[str, Any], out_dir: str) -> Path:
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S", time.localtime(scan["started"]))
    path = Path(out_dir) / f"scan-{stamp}.json"
    path.write_text(json.dumps(to_dict(scan), indent=2, default=str), encoding="utf-8")
    return path


# ---------------- html ----------------

_CSS = """
:root{--bg:#0e1116;--card:#161b22;--card2:#1c222b;--line:#2a323d;--text:#e6edf3;
--dim:#8b98a5;--faint:#5f6b78;--long:#3fb950;--short:#f85149;--warn:#d29922;--info:#58a6ff}
@media(prefers-color-scheme:light){:root{--bg:#f6f8fa;--card:#fff;--card2:#f0f3f6;
--line:#d8dee4;--text:#1f2328;--dim:#59636e;--faint:#818b96;--long:#1a7f37;
--short:#cf222e;--warn:#9a6700;--info:#0969da}}
*{box-sizing:border-box}
body{margin:0;padding:20px 16px 56px;background:var(--bg);color:var(--text);
font:15px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
max-width:820px;margin-inline:auto;-webkit-text-size-adjust:100%}
h1{font-size:21px;margin:0 0 4px;letter-spacing:-.01em}
.stamp{color:var(--faint);font-size:12px;font-variant-numeric:tabular-nums}
h2{font-size:12px;text-transform:uppercase;letter-spacing:.09em;color:var(--dim);
margin:30px 0 10px;font-weight:600}
.banner{background:var(--card2);border:1px solid var(--line);border-left:3px solid var(--warn);
border-radius:8px;padding:12px 14px;font-size:13px;color:var(--dim);margin:16px 0 4px}
.banner b{color:var(--text)}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;
padding:14px 16px;margin-bottom:10px}
.top{display:flex;align-items:baseline;gap:9px;flex-wrap:wrap;margin-bottom:3px}
.tkr{font-size:18px;font-weight:700}
.badge{margin-left:auto;font-size:11px;font-weight:700;padding:3px 9px;border-radius:20px;
letter-spacing:.04em;white-space:nowrap}
.b-long{background:color-mix(in srgb,var(--long) 16%,transparent);color:var(--long)}
.b-short{background:color-mix(in srgb,var(--short) 16%,transparent);color:var(--short)}
.b-warn{background:color-mix(in srgb,var(--warn) 18%,transparent);color:var(--warn)}
.b-info{background:color-mix(in srgb,var(--info) 16%,transparent);color:var(--info)}
.metrics{display:flex;gap:16px;flex-wrap:wrap;margin:9px 0 11px;font-size:12px;
color:var(--dim);font-variant-numeric:tabular-nums}
.metrics span b{color:var(--text);font-weight:600}
ul.ev{margin:0;padding-left:17px;font-size:13px;color:var(--dim)}
ul.ev li{margin-bottom:5px}
.flags{margin-top:9px;font-size:11px;color:var(--faint);letter-spacing:.03em}
footer{margin-top:34px;padding-top:16px;border-top:1px solid var(--line);
font-size:12px;color:var(--faint)}
"""

_BADGE = {
    "STRONG LONG": "b-long", "LEAN LONG": "b-long",
    "STRONG SHORT": "b-short", "LEAN SHORT": "b-short",
    "NEUTRAL": "b-info", "CONFLICT": "b-info", "EXCLUDED": "b-info",
    "CROWDED LONG": "b-warn", "CROWDED SHORT": "b-warn",
}


def _card(r: Result) -> str:
    s = r.signals
    e = _html.escape
    badge_cls = "b-warn" if "CROWDED" in r.flags else _BADGE.get(r.label, "b-info")
    metrics = [
        f"<span>score <b>{r.score:+.1f}</b></span>",
        f"<span>1d <b>{s.ret_1d:+.1f}%</b></span>",
        f"<span>5d <b>{s.ret_5d:+.1f}%</b></span>",
        f"<span>posts <b>{s.n_posts}</b></span>",
    ]
    if s.price:
        metrics.insert(0, f"<span>price <b>${s.price:,.2f}</b></span>")
    if s.rvol:
        metrics.append(f"<span>rvol <b>{s.rvol:.1f}x</b></span>")
    if s.st_tagged_ratio is not None:
        metrics.append(f"<span>ST bull <b>{s.st_tagged_ratio*100:.0f}%</b></span>")
    if s.short_pct_float:
        metrics.append(f"<span>short float <b>{s.short_pct_float:.0f}%</b></span>")

    ev = "".join(f"<li>{e(line)}</li>" for line in r.rationale) or "<li>No notes.</li>"
    flags = ", ".join(r.flags) if r.flags else "—"
    return f"""<div class="card">
<div class="top"><span class="tkr">{e(r.ticker)}</span>
<span class="badge {badge_cls}">{e(r.label)}</span></div>
<div class="metrics">{''.join(metrics)}</div>
<ul class="ev">{ev}</ul>
<div class="flags">{e(flags)}</div>
</div>"""


def write_html(scan: Dict[str, Any], out_dir: str) -> Path:
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    stamp_file = time.strftime("%Y%m%d-%H%M%S", time.localtime(scan["started"]))
    stamp_human = datetime.fromtimestamp(
        scan["started"], timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    buckets = scan["buckets"]

    sections = []
    for key in ("long", "short", "crowded", "conflict"):
        rows = buckets.get(key) or []
        if not rows:
            continue
        sections.append(f"<h2>{_html.escape(BUCKET_TITLES[key])}</h2>")
        sections.append("".join(_card(r) for r in rows))

    if not sections:
        sections.append(
            "<h2>No signal</h2><div class='card'>Nothing cleared the score "
            "threshold this scan. That is a valid result — most of the time "
            "there is nothing to do.</div>"
        )

    excluded = buckets.get("excluded") or []
    exc_note = ""
    if excluded:
        names = ", ".join(
            f"{_html.escape(r.ticker)} ({_html.escape(str(r.components.get('reason','')))})"
            for r in excluded[:12]
        )
        exc_note = f"<br><br><b>Excluded on liquidity/listing filters:</b> {names}"

    doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Sentiment Scan — {stamp_human}</title><style>{_CSS}</style></head><body>
<h1>Sentiment Scan</h1>
<div class="stamp">{stamp_human} · {len(scan['candidates'])} candidates ·
{scan['elapsed']:.1f}s</div>
<div class="banner"><b>Research signal, not advice.</b> Sentiment decays fast and is
heavily front-run. Every call shows its evidence and its flags so you are judging
the reasoning, not the verdict.</div>
{''.join(sections)}
<footer>Scored on blended social sentiment, explicit StockTwits tags and news flow,
weighted by chatter velocity against each ticker's own baseline, source
corroboration and poster agreement — then checked against the tape. Divergence,
crowding and capitulation guards are applied before ranking.{exc_note}
<br><br>Not investment advice.</footer></body></html>"""

    path = Path(out_dir) / f"scan-{stamp_file}.html"
    path.write_text(doc, encoding="utf-8")
    return path


# ---------------- review ----------------

def print_scorecard(card: Dict[str, Any]) -> None:
    if card.get("n", 0) == 0:
        print("No settled calls yet. Run `scan` a few times, then `review` "
              "after 24h+ so there are forward returns to grade.")
        return
    if Console is None:  # pragma: no cover
        print(json.dumps(card, indent=2))
        return
    con = Console()
    con.print(Panel(
        f"[bold]{card['n']}[/bold] settled calls · "
        f"hit rate [bold]{card['hit_rate']*100:.0f}%[/bold] · "
        f"avg signed return [bold]{card['avg_signed_return']:+.2f}%[/bold] · "
        f"median {card['median_signed_return']:+.2f}%\n"
        f"[dim]best {card['best']:+.1f}% · worst {card['worst']:+.1f}% · "
        f"a coin flip is 50% — treat anything near that as no edge.[/dim]",
        title="Scorecard", border_style="blue",
    ))
    t = Table(header_style="bold", border_style="blue")
    t.add_column("Label")
    t.add_column("N", justify="right")
    t.add_column("Hit rate", justify="right")
    t.add_column("Avg return", justify="right")
    for label, b in sorted(card["by_label"].items()):
        t.add_row(label, str(b["n"]), f"{b['hit_rate']*100:.0f}%",
                  f"{b['avg_return']:+.2f}%")
    con.print(t)
