"""Price, volume and liquidity via yfinance. No API key required.

Price is not the signal here — it is the CHECK on the signal. Chatter that
disagrees with the tape is the single most common way these tools go wrong.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

try:
    import yfinance as yf
except ImportError:  # pragma: no cover
    yf = None


class PriceSource:
    def __init__(self):
        if yf is None:
            raise RuntimeError("yfinance not installed; run: pip install yfinance")
        self._cache: Dict[str, Optional[Dict[str, Any]]] = {}

    def quote(self, ticker: str) -> Optional[Dict[str, Any]]:
        """Current price, 1d/5d returns, relative volume, market cap.

        Returns None if the symbol doesn't resolve — which doubles as the
        ticker validator, so bogus extractions get filtered for free.
        """
        ticker = ticker.upper()
        if ticker in self._cache:
            return self._cache[ticker]

        result: Optional[Dict[str, Any]] = None
        try:
            t = yf.Ticker(ticker)
            hist = t.history(period="3mo", interval="1d", auto_adjust=False)
            if hist is None or hist.empty or len(hist) < 2:
                self._cache[ticker] = None
                return None

            closes = hist["Close"].dropna()
            volumes = hist["Volume"].dropna()
            last = float(closes.iloc[-1])
            prev = float(closes.iloc[-2])
            ret_1d = (last - prev) / prev * 100.0 if prev else 0.0

            if len(closes) >= 6:
                base5 = float(closes.iloc[-6])
                ret_5d = (last - base5) / base5 * 100.0 if base5 else 0.0
            else:
                ret_5d = ret_1d

            if len(closes) >= 21:
                base20 = float(closes.iloc[-21])
                ret_20d = (last - base20) / base20 * 100.0 if base20 else 0.0
            else:
                ret_20d = ret_5d

            last_vol = float(volumes.iloc[-1]) if len(volumes) else 0.0
            avg_vol = float(volumes.tail(20).mean()) if len(volumes) >= 5 else last_vol
            rvol = (last_vol / avg_vol) if avg_vol else 1.0

            market_cap = None
            shares_short_pct = None
            try:
                info = t.get_info()
                market_cap = info.get("marketCap")
                sof = info.get("shortPercentOfFloat")
                if sof is not None:
                    shares_short_pct = float(sof) * 100.0
            except Exception as exc:  # info is the flakiest yfinance endpoint
                log.debug("info lookup failed for %s: %s", ticker, exc)

            result = {
                "ticker": ticker,
                "price": last,
                "ret_1d": ret_1d,
                "ret_5d": ret_5d,
                "ret_20d": ret_20d,
                "volume": last_vol,
                "avg_volume_20d": avg_vol,
                "rvol": rvol,
                "dollar_volume": last * avg_vol,
                "market_cap": market_cap,
                "short_pct_float": shares_short_pct,
            }
        except Exception as exc:
            log.warning("price fetch failed for %s: %s", ticker, exc)
            result = None

        self._cache[ticker] = result
        return result

    def validate(self, ticker: str) -> Optional[Dict[str, Any]]:
        """Adapter for TickerExtractor — truthy metadata means real symbol."""
        q = self.quote(ticker)
        if q is None:
            return None
        return {"price": q["price"], "market_cap": q.get("market_cap")}

    def passes_liquidity(self, quote: Dict[str, Any], min_price: float,
                         min_market_cap: float, min_dollar_volume: float) -> tuple[bool, str]:
        """Filter out the low-float pump names. These dominate raw % gainer
        lists and are where manipulation concentrates — a sentiment tool that
        doesn't exclude them is mostly a pump detector."""
        if quote.get("price") is not None and quote["price"] < min_price:
            return False, f"price ${quote['price']:.2f} < ${min_price:.2f}"
        mc = quote.get("market_cap")
        if mc is not None and mc < min_market_cap:
            return False, f"market cap ${mc/1e6:.0f}M < ${min_market_cap/1e6:.0f}M"
        dv = quote.get("dollar_volume")
        if dv is not None and dv < min_dollar_volume:
            return False, f"dollar volume ${dv/1e6:.1f}M < ${min_dollar_volume/1e6:.1f}M"
        return True, ""

    def price_now(self, ticker: str) -> Optional[float]:
        """Uncached spot price — used by `review` to settle past calls."""
        try:
            t = yf.Ticker(ticker.upper())
            hist = t.history(period="1d", interval="1m")
            if hist is not None and not hist.empty:
                return float(hist["Close"].dropna().iloc[-1])
            hist = t.history(period="5d", interval="1d")
            if hist is not None and not hist.empty:
                return float(hist["Close"].dropna().iloc[-1])
        except Exception as exc:
            log.warning("spot price failed for %s: %s", ticker, exc)
        return None
