"""StockTwits public API.

The most valuable social source available without a key, because a large share
of posts carry an EXPLICIT user-applied Bullish/Bearish tag. That is a labelled
sentiment signal rather than an inferred one — no NLP error in the middle.

Rate limit is roughly 200 requests/hour unauthenticated. The scanner respects
universe.max_candidates to stay under it.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

import requests

log = logging.getLogger(__name__)

BASE = "https://api.stocktwits.com/api/2"
TRENDING_URL = f"{BASE}/trending/symbols.json"
SYMBOL_URL = f"{BASE}/streams/symbol/{{symbol}}.json"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; sentiment-agent/1.0)",
    "Accept": "application/json",
}


class StockTwitsSource:
    name = "stocktwits"

    def __init__(self, posts_per_ticker: int = 30, timeout: int = 15,
                 session: Optional[requests.Session] = None):
        self.posts_per_ticker = posts_per_ticker
        self.timeout = timeout
        self.session = session or requests.Session()
        self.session.headers.update(HEADERS)

    def _get(self, url: str, params: Optional[dict] = None) -> Optional[dict]:
        for attempt in range(3):
            try:
                r = self.session.get(url, params=params, timeout=self.timeout)
                if r.status_code == 429:
                    wait = 2 ** attempt * 5
                    log.warning("StockTwits rate limited, sleeping %ss", wait)
                    time.sleep(wait)
                    continue
                r.raise_for_status()
                return r.json()
            except Exception as exc:
                log.debug("StockTwits GET failed (%s): %s", url, exc)
                if attempt == 2:
                    log.warning("StockTwits unavailable for %s: %s", url, exc)
                time.sleep(1)
        return None

    def trending(self, limit: int = 30) -> List[str]:
        data = self._get(TRENDING_URL)
        if not data:
            return []
        return [s["symbol"].upper() for s in data.get("symbols", [])][:limit]

    def fetch(self, ticker: str) -> Dict[str, Any]:
        """Posts plus the explicit bull/bear tag tally for one ticker."""
        data = self._get(SYMBOL_URL.format(symbol=ticker.upper()))
        empty = {
            "source": self.name, "ticker": ticker.upper(), "texts": [],
            "weights": [], "bull": 0, "bear": 0, "untagged": 0,
            "tagged_ratio": None, "available": False,
        }
        if not data:
            return empty

        messages = data.get("messages", [])[: self.posts_per_ticker]
        texts, weights = [], []
        bull = bear = untagged = 0

        for m in messages:
            body = m.get("body", "") or ""
            if body:
                texts.append(body)
                # Engagement weight — a post with replies/likes reached more
                # eyeballs than one that sank without trace.
                likes = (m.get("likes") or {}).get("total", 0) or 0
                replies = (m.get("conversation") or {}).get("replies", 0) or 0
                weights.append(1.0 + min(likes + replies, 50) / 10.0)

            basic = ((m.get("entities") or {}).get("sentiment") or {}).get("basic")
            if basic == "Bullish":
                bull += 1
            elif basic == "Bearish":
                bear += 1
            else:
                untagged += 1

        tagged = bull + bear
        return {
            "source": self.name,
            "ticker": ticker.upper(),
            "texts": texts,
            "weights": weights,
            "bull": bull,
            "bear": bear,
            "untagged": untagged,
            # None (not 0.5) when nobody tagged — "no data" and "perfectly
            # split" are different things and must not be averaged together.
            "tagged_ratio": (bull / tagged) if tagged else None,
            "n_tagged": tagged,
            "available": True,
        }
