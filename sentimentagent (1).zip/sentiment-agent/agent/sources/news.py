"""Headline flow via RSS. No API key.

News matters here less for its own sentiment than as the CATALYST CHECK: is the
chatter attached to a hard, dated event, or is it vibes? That distinction was
the difference between a real signal and a crowded squeeze in testing.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List
from urllib.parse import quote_plus

log = logging.getLogger(__name__)

try:
    import feedparser
except ImportError:  # pragma: no cover
    feedparser = None

YAHOO_RSS = "https://feeds.finance.yahoo.com/rss/2.0/headline?s={sym}&region=US&lang=en-US"
GOOGLE_RSS = ("https://news.google.com/rss/search?q={q}+stock&hl=en-US&gl=US&ceid=US:en")


class NewsSource:
    name = "news"

    def __init__(self, max_headlines: int = 15, timeout: int = 15):
        if feedparser is None:
            raise RuntimeError("feedparser not installed; run: pip install feedparser")
        self.max_headlines = max_headlines
        self.timeout = timeout

    def _parse(self, url: str) -> List[Dict[str, Any]]:
        try:
            feed = feedparser.parse(url)
            out = []
            for e in feed.entries[: self.max_headlines]:
                title = getattr(e, "title", "") or ""
                summary = getattr(e, "summary", "") or ""
                published = getattr(e, "published_parsed", None)
                out.append({
                    "title": title,
                    "summary": summary,
                    "text": f"{title}. {summary}".strip(),
                    "link": getattr(e, "link", ""),
                    "published": time.mktime(published) if published else None,
                })
            return out
        except Exception as exc:
            log.debug("RSS parse failed (%s): %s", url, exc)
            return []

    def fetch(self, ticker: str) -> Dict[str, Any]:
        sym = ticker.upper()
        items = self._parse(YAHOO_RSS.format(sym=sym))
        if len(items) < 3:
            items.extend(self._parse(GOOGLE_RSS.format(q=quote_plus(sym))))

        # De-dupe on title; the two feeds overlap heavily.
        seen, unique = set(), []
        for it in items:
            key = it["title"].strip().lower()
            if key and key not in seen:
                seen.add(key)
                unique.append(it)

        unique = unique[: self.max_headlines]
        return {
            "source": self.name,
            "ticker": sym,
            "items": unique,
            "texts": [i["text"] for i in unique],
            "available": bool(unique),
        }

    @staticmethod
    def recency_weights(items: List[Dict[str, Any]], half_life_hours: float = 24.0) -> List[float]:
        """Exponential decay — a headline from a week ago is not news."""
        now = time.time()
        weights = []
        for it in items:
            pub = it.get("published")
            if not pub:
                weights.append(0.5)
                continue
            age_h = max((now - pub) / 3600.0, 0.0)
            weights.append(0.5 ** (age_h / half_life_hours))
        return weights
