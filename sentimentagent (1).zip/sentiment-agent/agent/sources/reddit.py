"""Reddit ingestion.

Two modes:
  keyless — the public .json endpoints. No signup, but Reddit throttles hard
            and blocks default User-Agents, so a descriptive UA is required.
  praw    — authenticated. Higher limits, more history. Free credentials from
            https://www.reddit.com/prefs/apps ("script" type app).

Both return the same shape, so the rest of the agent doesn't care which ran.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

import requests

log = logging.getLogger(__name__)


class RedditSource:
    name = "reddit"

    def __init__(self, subreddits: List[str], posts_per_sub: int = 100,
                 include_comments: bool = True, comments_per_post: int = 40,
                 client_id: str = "", client_secret: str = "",
                 user_agent: str = "sentiment-agent/1.0 (personal research)",
                 timeout: int = 20):
        self.subreddits = subreddits
        self.posts_per_sub = posts_per_sub
        self.include_comments = include_comments
        self.comments_per_post = comments_per_post
        self.timeout = timeout
        self.user_agent = user_agent

        self._praw = None
        if client_id and client_secret:
            try:
                import praw
                self._praw = praw.Reddit(
                    client_id=client_id,
                    client_secret=client_secret,
                    user_agent=user_agent,
                )
                self._praw.read_only = True
                log.info("Reddit: using authenticated PRAW client")
            except ImportError:
                log.warning("praw not installed, falling back to keyless JSON")
            except Exception as exc:
                log.warning("PRAW init failed (%s), falling back to keyless", exc)

        self.session = requests.Session()
        self.session.headers.update(
            {"User-Agent": user_agent, "Accept": "application/json"}
        )

    # ---------------- keyless ----------------

    def _get_json(self, url: str, params: Optional[dict] = None) -> Optional[dict]:
        for attempt in range(3):
            try:
                r = self.session.get(url, params=params, timeout=self.timeout)
                if r.status_code in (429, 503):
                    wait = 2 ** attempt * 4
                    log.warning("Reddit throttled (%s), sleeping %ss", r.status_code, wait)
                    time.sleep(wait)
                    continue
                r.raise_for_status()
                return r.json()
            except Exception as exc:
                log.debug("Reddit GET failed (%s): %s", url, exc)
                if attempt == 2:
                    log.warning("Reddit unavailable for %s: %s", url, exc)
                time.sleep(1.5)
        return None

    def _fetch_keyless(self, sub: str) -> List[Dict[str, Any]]:
        items: List[Dict[str, Any]] = []
        for listing in ("hot", "new"):
            data = self._get_json(
                f"https://www.reddit.com/r/{sub}/{listing}.json",
                params={"limit": min(self.posts_per_sub, 100)},
            )
            if not data:
                continue
            for child in data.get("data", {}).get("children", []):
                d = child.get("data", {})
                if d.get("stickied"):
                    continue
                items.append({
                    "id": d.get("id"),
                    "text": f"{d.get('title','')} {d.get('selftext','')}".strip(),
                    "score": d.get("score", 0) or 0,
                    "comments": d.get("num_comments", 0) or 0,
                    "created": d.get("created_utc", 0),
                    "sub": sub,
                    "permalink": d.get("permalink", ""),
                })
            time.sleep(1.0)  # be a good citizen
        return items

    def _fetch_comments_keyless(self, sub: str, post_id: str) -> List[Dict[str, Any]]:
        data = self._get_json(
            f"https://www.reddit.com/r/{sub}/comments/{post_id}.json",
            params={"limit": self.comments_per_post, "sort": "top"},
        )
        out: List[Dict[str, Any]] = []
        if not data or len(data) < 2:
            return out
        for child in data[1].get("data", {}).get("children", [])[: self.comments_per_post]:
            d = child.get("data", {})
            body = d.get("body")
            if body and body not in ("[deleted]", "[removed]"):
                out.append({
                    "text": body,
                    "score": d.get("score", 0) or 0,
                    "comments": 0,
                    "sub": sub,
                })
        return out

    # ---------------- praw ----------------

    def _fetch_praw(self, sub: str) -> List[Dict[str, Any]]:  # pragma: no cover
        items: List[Dict[str, Any]] = []
        try:
            subreddit = self._praw.subreddit(sub)
            for submission in subreddit.hot(limit=self.posts_per_sub):
                if submission.stickied:
                    continue
                items.append({
                    "id": submission.id,
                    "text": f"{submission.title} {submission.selftext or ''}".strip(),
                    "score": submission.score,
                    "comments": submission.num_comments,
                    "created": submission.created_utc,
                    "sub": sub,
                    "permalink": submission.permalink,
                    "_obj": submission,
                })
        except Exception as exc:
            log.warning("PRAW fetch failed for r/%s: %s", sub, exc)
        return items

    def _fetch_comments_praw(self, submission) -> List[Dict[str, Any]]:  # pragma: no cover
        out: List[Dict[str, Any]] = []
        try:
            submission.comments.replace_more(limit=0)
            for c in submission.comments.list()[: self.comments_per_post]:
                if getattr(c, "body", None):
                    out.append({"text": c.body, "score": getattr(c, "score", 0),
                                "comments": 0, "sub": submission.subreddit.display_name})
        except Exception as exc:
            log.debug("PRAW comments failed: %s", exc)
        return out

    # ---------------- public ----------------

    def fetch_all(self) -> List[Dict[str, Any]]:
        """Every post/comment across configured subs, newest-ish first."""
        docs: List[Dict[str, Any]] = []
        for sub in self.subreddits:
            posts = self._fetch_praw(sub) if self._praw else self._fetch_keyless(sub)
            docs.extend(posts)

            if not self.include_comments:
                continue
            # Only pull comments for posts with real discussion — that is where
            # ticker mentions concentrate, and it saves a lot of requests.
            hot = sorted(posts, key=lambda p: p.get("comments", 0), reverse=True)[:10]
            for p in hot:
                if self._praw and p.get("_obj") is not None:
                    docs.extend(self._fetch_comments_praw(p["_obj"]))
                elif p.get("id"):
                    docs.extend(self._fetch_comments_keyless(sub, p["id"]))
                    time.sleep(1.0)

        for d in docs:
            d.pop("_obj", None)
        log.info("Reddit: collected %d documents", len(docs))
        return docs

    @staticmethod
    def weight(doc: Dict[str, Any]) -> float:
        """Upvotes as a proxy for reach. Capped — one viral post should not
        become the entire signal for a ticker."""
        score = max(doc.get("score", 0) or 0, 0)
        return 1.0 + min(score, 500) / 100.0
