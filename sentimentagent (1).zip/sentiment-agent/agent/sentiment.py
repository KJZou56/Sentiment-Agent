"""Sentiment scoring for financial social text.

Off-the-shelf VADER is trained on general English and is badly wrong on this
domain. It reads "puts" as neutral, "squeeze" as slightly negative, and has no
idea what a bagholder is. The FINANCE_LEXICON below patches the vocabulary that
actually moves these posts.

VADER is the default because it is instant and free. FinBERT is meaningfully
better on headline-style financial text but needs torch and is ~100x slower.
"""
from __future__ import annotations

import re
import statistics
from typing import Dict, Iterable, List, Optional

try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
except ImportError:  # pragma: no cover
    SentimentIntensityAnalyzer = None  # type: ignore


# VADER valence scale is roughly -4.0 .. +4.0
FINANCE_LEXICON: Dict[str, float] = {
    # --- direction / positions ---
    "calls": 1.6, "call": 0.4, "puts": -1.8, "put": -0.4,
    "long": 1.3, "longs": 1.1, "short": -1.3, "shorts": -1.0,
    "shorting": -1.6, "longing": 1.4, "buying": 1.4, "selling": -1.4,
    "bought": 1.2, "sold": -1.0, "adding": 1.2, "trimming": -0.9,
    "loading": 1.6, "dumping": -1.9, "holding": 0.5, "hodl": 1.4,

    # --- moves ---
    "moon": 2.9, "mooning": 3.1, "moonshot": 2.6, "rocket": 2.4,
    "ripping": 2.4, "rip": 1.6, "ripped": 2.0, "squeeze": 1.9,
    "squeezing": 2.1, "squeezed": 1.5, "breakout": 2.2, "breaking": 0.8,
    "rally": 2.0, "rallying": 2.1, "surge": 2.2, "surging": 2.3,
    "soar": 2.4, "soaring": 2.5, "spike": 1.4, "pop": 1.5, "popped": 1.6,
    "gap": 0.2, "gapped": 0.4, "run": 1.0, "running": 1.2, "runner": 1.6,
    "parabolic": 2.2, "melt": -1.0, "meltup": 2.3, "meltdown": -2.8,
    "tank": -2.5, "tanking": -2.7, "tanked": -2.5, "plunge": -2.7,
    "plunging": -2.8, "crash": -3.0, "crashing": -3.1, "crashed": -2.9,
    "dump": -2.2, "dumped": -2.2, "collapse": -3.0, "collapsing": -3.0,
    "bleeding": -2.3, "bleed": -2.0, "slide": -1.6, "sliding": -1.7,
    "slump": -2.0, "plummet": -2.9, "plummeted": -2.9, "nosedive": -2.9,
    "cratered": -2.8, "imploded": -3.0, "faceripper": 2.2,

    # --- levels / structure ---
    "ath": 2.0, "alltimehigh": 2.1, "breakdown": -2.1,
    "support": 0.8, "resistance": -0.5, "oversold": 0.9, "overbought": -0.9,
    "bottomed": 1.6, "topped": -1.5, "reversal": 0.3, "dip": -0.4,
    "dipped": -0.8, "correction": -1.4, "pullback": -1.0, "consolidating": 0.2,

    # --- fundamentals language ---
    "beat": 2.1, "beats": 2.1, "smashed": 2.6, "crushed": 2.4,
    "miss": -2.2, "missed": -2.2, "misses": -2.2, "whiffed": -2.3,
    "upgrade": 2.3, "upgraded": 2.3, "downgrade": -2.4, "downgraded": -2.4,
    "raised": 1.8, "raising": 1.7, "lowered": -1.8, "lowering": -1.8,
    "guidance": 0.0, "outlook": 0.0, "guided": 0.0,
    "dilution": -2.4, "diluted": -2.0, "offering": -1.8, "buyback": 2.0,
    "bankruptcy": -3.6, "insolvent": -3.4, "delisted": -3.3, "halted": -1.6,
    "fraud": -3.5, "probe": -2.0, "subpoena": -2.4, "lawsuit": -1.9,
    "recall": -2.2, "approval": 2.3, "approved": 2.3, "rejected": -2.6,
    "contract": 1.4, "awarded": 1.9, "partnership": 1.6, "acquisition": 1.5,
    "buyout": 2.0, "merger": 1.2, "insider": 0.0,

    # --- slang ---
    "tendies": 2.6, "bagholder": -2.5, "bagholding": -2.5, "bags": -1.6,
    "yolo": 1.0, "fomo": 0.6, "rekt": -2.9, "rugged": -3.0, "rugpull": -3.2,
    "printing": 2.3, "printed": 2.1, "bullish": 2.6, "bearish": -2.6,
    "bull": 1.8, "bear": -1.8, "bulls": 1.5, "bears": -1.5,
    "gains": 2.0, "losses": -2.0, "loss": -1.6, "porn": 0.0,
    "guh": -2.6, "cope": -1.4, "copium": -1.6, "hopium": -0.8,
    "drilling": -2.4, "dogshit": -3.0, "garbage": -2.6, "trash": -2.5,
    "undervalued": 2.0, "overvalued": -2.0, "cheap": 1.2, "expensive": -1.0,
    "conviction": 1.2, "risky": -1.0, "safe": 1.0,
    "dd": 0.3, "catalyst": 1.2, "pump": 0.6, "pumped": 0.5, "pumping": 0.6,
    "manipulation": -1.8, "halt": -1.4,
}

EMOJI_LEXICON: Dict[str, float] = {
    "\U0001F680": 2.8,   # rocket
    "\U0001F319": 2.0,   # crescent moon
    "\U0001F48E": 1.8,   # gem
    "\U0001F64C": 1.4,   # raised hands
    "\U0001F4C8": 2.0,   # chart increasing
    "\U0001F4C9": -2.0,  # chart decreasing
    "\U0001F43B": -1.8,  # bear
    "\U0001F308": -1.2,  # rainbow (rainbow bear = bearish in WSB slang)
    "\U0001F4B0": 1.6,   # money bag
    "\U0001F4B8": -1.2,  # money with wings
    "\U0001F525": 1.6,   # fire
    "\U0001F9FB": -2.0,  # roll of paper
    "\U0001FAE0": -1.6,  # melting face
    "\U0001F4A9": -2.4,  # pile of poo
    "\U0001F480": -2.2,  # skull
    "\U0001F602": 0.0,   # laughing — genuinely ambiguous here
}

_URL_RE = re.compile(r"https?://\S+")
_CASHTAG_RE = re.compile(r"\$[A-Za-z]{1,5}\b")
_WS_RE = re.compile(r"\s+")

# ---------------------------------------------------------------------------
# Phrase rules, applied BEFORE the bag-of-words pass.
#
# VADER sums word valences, which inverts on a whole class of finance idioms.
# "shorts are getting rekt" is three negative words and one of the most
# bullish sentences on the site — somebody ELSE is losing money. Word-level
# scoring cannot recover that; the phrase has to be rewritten first.
# ---------------------------------------------------------------------------
_CONNECTOR = (
    r"(?:\s+(?:are|is|were|was|get|gets|getting|got|gonna|being|been|all|now|"
    r"so|totally|absolutely|really|about\s+to\s+be))*\s+"
)
_PAIN = (r"(rekt|destroyed|crushed|obliterated|squeezed|cooked|wrecked|"
         r"trapped|panicking|covering|capitulating|liquidated|toast)")

PHRASE_RULES: List[tuple[re.Pattern, str]] = [
    # Pain inflicted on the other side of the trade flips polarity.
    (re.compile(rf"\b(?:shorts?|bears?)\b{_CONNECTOR}{_PAIN}\b", re.I),
     " squeeze mooning "),
    (re.compile(rf"\b(?:bulls?|longs?)\b{_CONNECTOR}{_PAIN}\b", re.I),
     " crashing rekt "),

    (re.compile(r"\b(?:short|gamma)\s+squeeze\b", re.I), " squeeze mooning "),
    (re.compile(r"\bshorts?\s+cover(?:ing|ed)?\b", re.I), " squeeze "),
    (re.compile(r"\bcalls?\s+(?:are\s+)?printing\b", re.I), " mooning "),
    (re.compile(r"\bputs?\s+(?:are\s+)?printing\b", re.I), " crashing "),
    (re.compile(r"\bto\s+the\s+moon\b", re.I), " moon mooning "),
    (re.compile(r"\bdiamond\s+hands?\b", re.I), " hodl bullish "),
    (re.compile(r"\bpaper\s+hands?\b", re.I), " selling "),
    (re.compile(r"\bholding\s+the\s+bag\b", re.I), " bagholder "),
    (re.compile(r"\bcut\s+(?:my|the|his|her|their)\s+loss(?:es)?\b", re.I), " losses "),
    (re.compile(r"\bcatching\s+a\s+falling\s+knife\b", re.I), " crashing "),
    (re.compile(r"\bdead\s+cat\s+bounce\b", re.I), " crashing "),
    (re.compile(r"\bbag\s*hold(?:ing|er)s?\b", re.I), " bagholder "),
]

# VADER substitutes emoji for their *text descriptions* before lexicon lookup,
# so entries keyed on the raw glyph silently never fire. Mapping each glyph to
# a word we already score routes around that entirely.
EMOJI_TO_TOKEN: Dict[str, str] = {
    "\U0001F680": "moon",      "\U0001F319": "moon",
    "\U0001F4C8": "rally",     "\U0001F4C9": "tanking",
    "\U0001F43B": "bearish",   "\U0001F308": "bearish",
    "\U0001F48E": "hodl",      "\U0001F64C": "bullish",
    "\U0001F4B0": "tendies",   "\U0001F4B8": "losses",
    "\U0001F525": "ripping",   "\U0001F9FB": "rekt",
    "\U0001FAE0": "rekt",      "\U0001F4A9": "dogshit",
    "\U0001F480": "rekt",      "\U0001F602": "",
}
_EMOJI_RE = re.compile("|".join(re.escape(k) for k in EMOJI_TO_TOKEN))

# Hard, dated, checkable events. Chatter backed by one of these is worth far
# more than chatter backed by vibes — this is the RKLB-vs-hype distinction.
CATALYST_PATTERNS = [
    r"\bearnings\b", r"\bq[1-4]\b", r"\bguidance\b", r"\bbeat[s]?\b",
    r"\bmiss(?:ed|es)?\b", r"\bupgrade[d]?\b", r"\bdowngrade[d]?\b",
    r"\bprice target\b", r"\bcontract\b", r"\bawarded\b", r"\bfda\b",
    r"\bapproval\b", r"\bphase [123]\b", r"\bmerger\b", r"\bacquisition\b",
    r"\bacquire[sd]?\b", r"\bbuyout\b", r"\bpartnership\b", r"\boffering\b",
    r"\bsplit\b", r"\bdividend\b", r"\bbuyback\b", r"\bsec filing\b",
    r"\b8-k\b", r"\b10-[qk]\b", r"\blawsuit\b", r"\brecall\b",
    r"\bbankruptcy\b", r"\bchapter 11\b", r"\bceo\b", r"\bresign(?:ed|s)?\b",
]
_CATALYST_RE = re.compile("|".join(CATALYST_PATTERNS), re.IGNORECASE)


def clean(text: str) -> str:
    text = _URL_RE.sub(" ", text or "")
    text = _CASHTAG_RE.sub(lambda m: m.group(0)[1:], text)  # $NVDA -> NVDA
    return _WS_RE.sub(" ", text).strip()


def normalize(text: str) -> str:
    """clean() plus emoji expansion and phrase rewriting.

    Order matters: emoji become words first, then multi-word idioms are
    collapsed, then the bag-of-words scorer sees something it can handle.
    """
    text = clean(text)
    if not text:
        return ""
    text = _EMOJI_RE.sub(lambda m: f" {EMOJI_TO_TOKEN[m.group(0)]} ", text)
    for pattern, replacement in PHRASE_RULES:
        text = pattern.sub(replacement, text)
    return _WS_RE.sub(" ", text).strip()


def has_catalyst(text: str) -> bool:
    return bool(_CATALYST_RE.search(text or ""))


class SentimentEngine:
    """Scores text to a float in [-1, 1]."""

    def __init__(self, engine: str = "vader", finbert_model: str = "ProsusAI/finbert"):
        self.engine = engine
        self._finbert = None
        self._vader = None
        if engine == "finbert":
            self._init_finbert(finbert_model)
        else:
            self._init_vader()

    def _init_vader(self) -> None:
        if SentimentIntensityAnalyzer is None:
            raise RuntimeError(
                "vaderSentiment not installed; run: pip install vaderSentiment"
            )
        self._vader = SentimentIntensityAnalyzer()
        self._vader.lexicon.update(FINANCE_LEXICON)
        self._vader.lexicon.update(EMOJI_LEXICON)

    def _init_finbert(self, model_name: str) -> None:  # pragma: no cover
        try:
            from transformers import pipeline
        except ImportError:
            raise RuntimeError(
                "finbert engine needs: pip install transformers torch"
            )
        self._finbert = pipeline(
            "sentiment-analysis", model=model_name, truncation=True, max_length=512
        )

    def score(self, text: str) -> float:
        if self._finbert is not None:  # pragma: no cover
            # FinBERT reads real sentences — give it the lightly cleaned text,
            # not the token soup the phrase rules produce for VADER.
            text = clean(text)
            if not text:
                return 0.0
            res = self._finbert(text)[0]
            label = res["label"].lower()
            conf = float(res["score"])
            if label.startswith("pos"):
                return conf
            if label.startswith("neg"):
                return -conf
            return 0.0
        text = normalize(text)
        if not text:
            return 0.0
        return float(self._vader.polarity_scores(text)["compound"])

    def score_many(self, texts: Iterable[str],
                   weights: Optional[List[float]] = None) -> Dict[str, float]:
        """Aggregate a batch of posts.

        Returns mean (optionally engagement-weighted), agreement (what share of
        non-neutral posts point the dominant way), and the raw counts. Agreement
        matters: 50 posts split evenly is a fight, not a signal.
        """
        texts = list(texts)
        scores = [self.score(t) for t in texts]
        nonzero = [s for s in scores if abs(s) > 0.05]

        if not scores:
            return {"mean": 0.0, "agreement": 0.5, "n": 0, "n_directional": 0,
                    "pos": 0, "neg": 0, "stdev": 0.0}

        if weights and len(weights) == len(scores):
            wsum = sum(weights) or 1.0
            mean = sum(s * w for s, w in zip(scores, weights)) / wsum
        else:
            mean = statistics.fmean(scores)

        pos = sum(1 for s in nonzero if s > 0)
        neg = sum(1 for s in nonzero if s < 0)
        agreement = (max(pos, neg) / len(nonzero)) if nonzero else 0.5

        return {
            "mean": mean,
            "agreement": agreement,
            "n": len(scores),
            "n_directional": len(nonzero),
            "pos": pos,
            "neg": neg,
            "stdev": statistics.pstdev(scores) if len(scores) > 1 else 0.0,
        }
