"""Orchestration: discover candidates -> gather -> score -> rank."""
from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

from .config import Config
from .score import Result, Signals, rank, score_ticker
from .sentiment import SentimentEngine, has_catalyst
from .sources.news import NewsSource
from .sources.prices import PriceSource
from .sources.reddit import RedditSource
from .sources.stocktwits import StockTwitsSource
from .store import Store
from .tickers import TickerExtractor

log = logging.getLogger(__name__)


class Scanner:
    def __init__(self, cfg: Config, store: Store):
        self.cfg = cfg
        self.store = store
        self.sentiment = SentimentEngine(
            engine=cfg.get("sentiment.engine", "vader"),
            finbert_model=cfg.get("sentiment.finbert_model", "ProsusAI/finbert"),
        )
        self.prices = PriceSource()
        self.extractor = TickerExtractor(validator=self.prices.validate, store=store)

        self.stocktwits = (
            StockTwitsSource(posts_per_ticker=cfg.get("sources.stocktwits.posts_per_ticker", 30))
            if cfg.get("sources.stocktwits.enabled", True) else None
        )
        self.reddit = (
            RedditSource(
                subreddits=cfg.get("sources.reddit.subreddits", []),
                posts_per_sub=cfg.get("sources.reddit.posts_per_sub", 100),
                include_comments=cfg.get("sources.reddit.include_comments", True),
                comments_per_post=cfg.get("sources.reddit.comments_per_post", 40),
                client_id=cfg.get("sources.reddit.client_id", ""),
                client_secret=cfg.get("sources.reddit.client_secret", ""),
                user_agent=cfg.get("sources.reddit.user_agent", "sentiment-agent/1.0"),
            )
            if cfg.get("sources.reddit.enabled", True) else None
        )
        self.news = (
            NewsSource(max_headlines=cfg.get("sources.news.max_headlines", 15))
            if cfg.get("sources.news.enabled", True) else None
        )

    # ---------------- discovery ----------------

    def discover(self) -> tuple[List[str], Dict[str, Any]]:
        """Build the candidate list and collect the Reddit corpus once."""
        mode = self.cfg.get("universe.mode", "chatter")
        max_n = self.cfg.get("universe.max_candidates", 25)
        candidates: List[str] = []
        corpus: List[Dict[str, Any]] = []
        reddit_counts: Dict[str, int] = {}

        if mode in ("watchlist", "both"):
            candidates.extend([t.upper() for t in self.cfg.get("universe.watchlist", [])])

        if mode in ("chatter", "both"):
            if self.reddit is not None:
                corpus = self.reddit.fetch_all()
                texts = [d["text"] for d in corpus if d.get("text")]
                reddit_counts = self.extractor.count(texts, validate_bare=True)
                ranked = sorted(reddit_counts.items(), key=lambda kv: -kv[1])
                candidates.extend([sym for sym, _ in ranked[: max_n]])
            if self.stocktwits is not None:
                candidates.extend(self.stocktwits.trending(limit=15))

        # de-dupe, preserve order
        seen, ordered = set(), []
        for c in candidates:
            if c not in seen:
                seen.add(c)
                ordered.append(c)

        return ordered[:max_n], {"corpus": corpus, "reddit_counts": reddit_counts}

    # ---------------- per-ticker gather ----------------

    def gather(self, ticker: str, ctx: Dict[str, Any]) -> Signals:
        sig = Signals(ticker=ticker)
        now = time.time()

        quote = self.prices.quote(ticker)
        if quote is None:
            sig.excluded_reason = "symbol did not resolve to a tradable listing"
            return sig

        ok, why = self.prices.passes_liquidity(
            quote,
            self.cfg.get("universe.min_price", 1.50),
            self.cfg.get("universe.min_market_cap", 300_000_000),
            self.cfg.get("universe.min_dollar_volume", 5_000_000),
        )
        if not ok:
            sig.excluded_reason = why
            return sig

        sig.price = quote["price"]
        sig.ret_1d = quote["ret_1d"]
        sig.ret_5d = quote["ret_5d"]
        sig.rvol = quote["rvol"]
        sig.market_cap = quote.get("market_cap")
        sig.dollar_volume = quote.get("dollar_volume")
        sig.short_pct_float = quote.get("short_pct_float")

        social_texts: List[str] = []
        social_weights: List[float] = []

        # --- reddit (already fetched once for the whole scan) ---
        corpus = ctx.get("corpus", [])
        if corpus:
            hits = [d for d in corpus
                    if ticker in self.extractor.extract(d.get("text", ""), validate_bare=False)
                    or f"${ticker}" in (d.get("text", "") or "").upper()]
            if hits:
                sig.sources_present.append("reddit")
                for d in hits:
                    social_texts.append(d["text"])
                    social_weights.append(RedditSource.weight(d))
                count = ctx.get("reddit_counts", {}).get(ticker, len(hits))
                sig.mention_count += count
                self.store.record_mentions(ticker, "reddit", count, ts=now)

        # --- stocktwits ---
        if self.stocktwits is not None:
            st = self.stocktwits.fetch(ticker)
            if st.get("available") and st.get("texts"):
                sig.sources_present.append("stocktwits")
                social_texts.extend(st["texts"])
                social_weights.extend(st["weights"])
                sig.st_tagged_ratio = st.get("tagged_ratio")
                sig.st_n_tagged = st.get("n_tagged", 0)
                n = len(st["texts"])
                sig.mention_count += n
                self.store.record_mentions(ticker, "stocktwits", n, ts=now)

        if social_texts:
            agg = self.sentiment.score_many(social_texts, social_weights)
            sig.social_mean = agg["mean"]
            sig.social_agreement = agg["agreement"]
            sig.n_posts = agg["n"]

        # --- news ---
        if self.news is not None:
            nw = self.news.fetch(ticker)
            if nw.get("available"):
                sig.sources_present.append("news")
                items = nw["items"]
                weights = NewsSource.recency_weights(items)
                agg = self.sentiment.score_many(nw["texts"], weights)
                sig.news_mean = agg["mean"]
                sig.n_headlines = agg["n"]
                sig.has_catalyst = any(has_catalyst(t) for t in nw["texts"])

        if social_texts and not sig.has_catalyst:
            sig.has_catalyst = any(has_catalyst(t) for t in social_texts[:50])

        baseline = self.store.mention_baseline(ticker, now=now)
        sig.mention_baseline_mean = baseline["mean"]
        sig.mention_baseline_stdev = baseline["stdev"]
        sig.mention_baseline_n = int(baseline["n"])

        return sig

    # ---------------- run ----------------

    def scan(self) -> Dict[str, Any]:
        started = time.time()
        candidates, ctx = self.discover()
        log.info("Scanning %d candidates: %s", len(candidates), ", ".join(candidates))

        results: List[Result] = []
        scoring_cfg = self.cfg.get("scoring", {})
        for tk in candidates:
            try:
                sig = self.gather(tk, ctx)
                results.append(score_ticker(sig, scoring_cfg))
            except Exception as exc:
                log.warning("scoring failed for %s: %s", tk, exc)

        buckets = rank(
            results,
            min_abs_score=self.cfg.get("output.min_abs_score", 2.0),
            top_n=self.cfg.get("output.top_n", 10),
        )

        # Journal every actionable call so `review` can grade it later.
        for bucket in ("long", "short"):
            for r in buckets[bucket]:
                self.store.record_call(
                    r.ticker, r.label, r.score, r.signals.price, r.flags,
                    {"rationale": r.rationale, "components": r.components},
                    ts=started,
                )

        return {
            "started": started,
            "elapsed": time.time() - started,
            "candidates": candidates,
            "results": results,
            "buckets": buckets,
        }
