"""Config loading with defaults, so the agent runs before you edit anything."""
from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any, Dict

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

DEFAULTS: Dict[str, Any] = {
    "universe": {
        "mode": "chatter",
        "watchlist": [],
        "max_candidates": 25,
        "min_price": 1.50,
        "min_market_cap": 300_000_000,
        "min_dollar_volume": 5_000_000,
    },
    "sources": {
        "stocktwits": {"enabled": True, "posts_per_ticker": 30},
        "reddit": {
            "enabled": True,
            "subreddits": ["wallstreetbets", "stocks", "investing", "stockmarket"],
            "posts_per_sub": 100,
            "include_comments": True,
            "comments_per_post": 40,
            "client_id": "",
            "client_secret": "",
            "user_agent": "sentiment-agent/1.0 (personal research)",
        },
        "news": {"enabled": True, "max_headlines": 15},
    },
    "sentiment": {"engine": "vader", "finbert_model": "ProsusAI/finbert"},
    "scoring": {
        "weights": {
            "social_sentiment": 0.45,
            "stocktwits_tags": 0.35,
            "news_sentiment": 0.20,
        },
        "conviction": {"velocity": 0.45, "agreement": 0.30, "corroboration": 0.25},
        "divergence": {"enabled": True, "min_move_pct": 3.0, "penalty": 0.35},
        "crowding": {
            "enabled": True,
            "run_pct_5d": 25.0,
            "velocity_threshold": 0.80,
            "score_cap": 3.0,
        },
        "capitulation": {"enabled": True, "drop_pct_1d": -20.0, "score_floor": -3.0},
        "catalyst_bonus": 1.15,
    },
    "output": {
        "dir": "./reports",
        "html": True,
        "json": True,
        "min_abs_score": 2.0,
        "top_n": 10,
    },
    "watch": {"interval_seconds": 900, "market_hours_only": True},
}


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(base)
    for key, val in (override or {}).items():
        if isinstance(val, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], val)
        else:
            out[key] = val
    return out


class Config:
    def __init__(self, data: Dict[str, Any]):
        self._d = data

    def __getitem__(self, key: str) -> Any:
        return self._d[key]

    def get(self, path: str, default: Any = None) -> Any:
        """Dotted lookup: cfg.get('scoring.crowding.score_cap')."""
        node: Any = self._d
        for part in path.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    @property
    def raw(self) -> Dict[str, Any]:
        return self._d

    def validate(self) -> list[str]:
        """Return a list of human-readable problems. Empty means good."""
        problems = []
        w = self.get("scoring.weights", {})
        total = sum(w.values()) if w else 0
        if abs(total - 1.0) > 1e-6:
            problems.append(
                f"scoring.weights must sum to 1.0, got {total:.3f} ({w})"
            )
        c = self.get("scoring.conviction", {})
        ctotal = sum(c.values()) if c else 0
        if abs(ctotal - 1.0) > 1e-6:
            problems.append(
                f"scoring.conviction must sum to 1.0, got {ctotal:.3f} ({c})"
            )
        if self.get("sentiment.engine") not in ("vader", "finbert"):
            problems.append("sentiment.engine must be 'vader' or 'finbert'")
        if self.get("universe.mode") not in ("chatter", "watchlist", "both"):
            problems.append("universe.mode must be chatter, watchlist or both")
        if self.get("universe.mode") in ("watchlist", "both") and not self.get(
            "universe.watchlist"
        ):
            problems.append("universe.mode needs a non-empty universe.watchlist")
        return problems


def load(path: str | os.PathLike | None = None) -> Config:
    data = DEFAULTS
    candidate = Path(path) if path else Path("config.yaml")
    if candidate.exists():
        if yaml is None:
            raise RuntimeError("PyYAML not installed; run: pip install pyyaml")
        with open(candidate, "r", encoding="utf-8") as fh:
            user = yaml.safe_load(fh) or {}
        data = _deep_merge(DEFAULTS, user)
    return Config(data)
