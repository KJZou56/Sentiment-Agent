"""The scoring rubric — the part that decides whether this is a research tool
or a noise amplifier.

Pure functions, no network, no I/O. That is deliberate: the whole model is
unit-testable against replayed setups (see tests/test_score.py).

Design notes, each earned from a real failure mode:

  DIVERGENCE — a mention spike says people are TALKING, not that they are
    BUYING. A stock that beats earnings, guides down and drops 5% produces a
    huge bullish-looking chatter spike. Scoring on volume alone calls that a
    buy on the day it sells off. So: when chatter direction and price direction
    disagree materially, the score is cut hard and the call is flagged.

  CROWDING — sentiment peaks at the END of a move, not the start. A name that
    has already run 25%+ and is simultaneously maxing out chatter velocity is
    late. It gets capped, not promoted. The loudest ticker on the board is
    usually the most dangerous one.

  CATALYST — chatter attached to a dated, checkable event (contract, earnings,
    approval) is worth more than chatter attached to vibes. Small multiplier,
    applied in the direction of the sentiment.

  CAPITULATION — the symmetric short guard. After a -28% gap the easy move is
    gone and bounces are violent. Don't chase.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

# Label boundaries on the final -10..+10 score. Deliberately symmetric: +3.0
# reads LEAN LONG, so -3.0 must read LEAN SHORT. An earlier version returned
# NEUTRAL at exactly -3.0 while still ranking the name in the short bucket.
STRONG = 6.0
LEAN = 3.0


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def label_for(score: float, flags: List[str]) -> str:
    if "EXCLUDED" in flags:
        return "EXCLUDED"
    if "SIGNAL_CONFLICT" in flags:
        return "CONFLICT"
    if "CROWDED" in flags:
        # Direction alone is misleading here — the whole point of the flag is
        # that the move is late. Say so in the label, not just the metadata.
        return "CROWDED LONG" if score > 0 else "CROWDED SHORT"
    if score >= STRONG:
        return "STRONG LONG"
    if score >= LEAN:
        return "LEAN LONG"
    if score > -LEAN:
        return "NEUTRAL"
    if score > -STRONG:
        return "LEAN SHORT"
    return "STRONG SHORT"


@dataclass
class Signals:
    """Everything measured about one ticker in one scan."""
    ticker: str
    # social
    social_mean: float = 0.0          # [-1,1] inferred sentiment
    social_agreement: float = 0.5     # [0.5,1] how much posters agree
    n_posts: int = 0
    mention_count: int = 0
    mention_baseline_mean: float = 0.0
    mention_baseline_stdev: float = 0.0
    mention_baseline_n: int = 0
    # stocktwits explicit tags
    st_tagged_ratio: Optional[float] = None   # bull/(bull+bear), None if untagged
    st_n_tagged: int = 0
    # news
    news_mean: float = 0.0
    n_headlines: int = 0
    has_catalyst: bool = False
    # market
    price: Optional[float] = None
    ret_1d: float = 0.0
    ret_5d: float = 0.0
    rvol: float = 1.0
    market_cap: Optional[float] = None
    dollar_volume: Optional[float] = None
    short_pct_float: Optional[float] = None
    # bookkeeping
    sources_present: List[str] = field(default_factory=list)
    excluded_reason: Optional[str] = None


@dataclass
class Result:
    ticker: str
    score: float
    label: str
    flags: List[str]
    components: Dict[str, Any]
    rationale: List[str]
    signals: Signals


def velocity(sig: Signals) -> float:
    """How unusual is this ticker's chatter *for this ticker*, in [0,1].

    Absolute mention counts are meaningless across tickers — SPY always has
    hundreds. What matters is deviation from its own baseline. With no history
    yet we return a neutral 0.5 rather than pretending to see a spike.
    """
    if sig.mention_baseline_n < 3:
        return 0.5
    mean = sig.mention_baseline_mean
    stdev = sig.mention_baseline_stdev
    if stdev > 0:
        z = (sig.mention_count - mean) / stdev
        return _clamp(z / 3.0, 0.0, 1.0)
    if mean > 0:
        ratio = sig.mention_count / mean
        return _clamp((ratio - 1.0) / 2.0, 0.0, 1.0)
    return 0.5 if sig.mention_count == 0 else 1.0


def blended_sentiment(sig: Signals, weights: Dict[str, float]) -> tuple[float, Dict[str, Any]]:
    """Combine inferred social, explicit StockTwits tags, and news into [-1,1].

    Missing channels are dropped and the remaining weights renormalised, so a
    ticker with no StockTwits coverage isn't silently pulled toward zero.
    """
    parts: Dict[str, Any] = {}
    active: List[tuple[float, float]] = []

    if sig.n_posts > 0:
        parts["social"] = sig.social_mean
        active.append((weights.get("social_sentiment", 0.45), sig.social_mean))

    if sig.st_tagged_ratio is not None and sig.st_n_tagged >= 3:
        st_signed = (sig.st_tagged_ratio - 0.5) * 2.0   # 0..1 -> -1..1
        parts["stocktwits"] = st_signed
        active.append((weights.get("stocktwits_tags", 0.35), st_signed))

    if sig.n_headlines > 0:
        parts["news"] = sig.news_mean
        active.append((weights.get("news_sentiment", 0.20), sig.news_mean))

    if not active:
        return 0.0, parts

    total_w = sum(w for w, _ in active)
    blended = sum(w * v for w, v in active) / total_w if total_w else 0.0
    parts["blended"] = blended
    return _clamp(blended, -1.0, 1.0), parts


def conviction(sig: Signals, cfg: Dict[str, float]) -> tuple[float, Dict[str, float]]:
    """How much to trust the direction, in [0,1]."""
    v = velocity(sig)
    # agreement arrives as 0.5..1.0; stretch to 0..1
    agree = _clamp((sig.social_agreement - 0.5) * 2.0, 0.0, 1.0)
    corrob = _clamp(len(sig.sources_present) / 3.0, 0.0, 1.0)
    total = (
        cfg.get("velocity", 0.45) * v
        + cfg.get("agreement", 0.30) * agree
        + cfg.get("corroboration", 0.25) * corrob
    )
    return _clamp(total, 0.0, 1.0), {"velocity": v, "agreement": agree,
                                     "corroboration": corrob, "conviction": total}


def score_ticker(sig: Signals, scoring_cfg: Dict[str, Any]) -> Result:
    flags: List[str] = []
    rationale: List[str] = []

    if sig.excluded_reason:
        return Result(sig.ticker, 0.0, "EXCLUDED", ["EXCLUDED"],
                      {"reason": sig.excluded_reason},
                      [f"Excluded: {sig.excluded_reason}"], sig)

    weights = scoring_cfg.get("weights", {})
    s, parts = blended_sentiment(sig, weights)
    conv, conv_parts = conviction(sig, scoring_cfg.get("conviction", {}))

    # Base: direction scaled by conviction. The 0.40 floor means a clear signal
    # still registers even with thin corroboration — just muted.
    base = s * (0.40 + 0.60 * conv) * 10.0
    components: Dict[str, Any] = {
        "sentiment": parts, "conviction": conv_parts, "base": base
    }

    if abs(s) > 0.05:
        rationale.append(
            f"Blended sentiment {s:+.2f} across {len(sig.sources_present)} source(s); "
            f"conviction {conv:.2f} (velocity {conv_parts['velocity']:.2f}, "
            f"agreement {conv_parts['agreement']:.2f})."
        )

    score = base

    # --- price confirmation / divergence guard -------------------------------
    div_cfg = scoring_cfg.get("divergence", {})
    if div_cfg.get("enabled", True) and sig.price is not None:
        same_way = (s > 0 and sig.ret_1d > 0) or (s < 0 and sig.ret_1d < 0)
        min_move = div_cfg.get("min_move_pct", 3.0)
        if abs(s) > 0.10 and abs(sig.ret_1d) >= min_move:
            if same_way:
                score *= 1.15
                flags.append("PRICE_CONFIRMED")
                rationale.append(
                    f"Tape agrees: {sig.ret_1d:+.1f}% on the day, same direction "
                    f"as the chatter."
                )
            else:
                score *= div_cfg.get("penalty", 0.35)
                flags.append("SIGNAL_CONFLICT")
                rationale.append(
                    f"CONFLICT: sentiment reads {s:+.2f} but price moved "
                    f"{sig.ret_1d:+.1f}%. High chatter on an opposing move usually "
                    f"means people are discussing the move, not causing it. "
                    f"Signal discounted."
                )

    # --- catalyst quality ----------------------------------------------------
    if sig.has_catalyst and abs(s) > 0.05:
        score *= scoring_cfg.get("catalyst_bonus", 1.15)
        flags.append("HARD_CATALYST")
        rationale.append("Chatter is attached to a dated, checkable event.")
    elif abs(s) > 0.30 and sig.n_headlines > 0 and not sig.has_catalyst:
        flags.append("NO_CATALYST")
        rationale.append("Strong sentiment with no hard news behind it — vibes.")

    # --- crowding guard ------------------------------------------------------
    crowd = scoring_cfg.get("crowding", {})
    if crowd.get("enabled", True) and score > 0:
        v = conv_parts["velocity"]
        if sig.ret_5d >= crowd.get("run_pct_5d", 25.0) and v >= crowd.get(
            "velocity_threshold", 0.80
        ):
            cap = crowd.get("score_cap", 3.0)
            if score > cap:
                rationale.append(
                    f"CROWDED: already +{sig.ret_5d:.0f}% over 5 days with chatter at "
                    f"{v:.2f} velocity. Sentiment peaks at the end of moves, not the "
                    f"start — capped at {cap:.1f}."
                )
                score = cap
            flags.append("CROWDED")

    # --- capitulation guard (symmetric, for shorts) --------------------------
    cap_cfg = scoring_cfg.get("capitulation", {})
    if cap_cfg.get("enabled", True) and score < 0:
        if sig.ret_1d <= cap_cfg.get("drop_pct_1d", -20.0):
            floor = cap_cfg.get("score_floor", -3.0)
            if score < floor:
                rationale.append(
                    f"CAPITULATION: already {sig.ret_1d:.0f}% on the day. Chasing a "
                    f"gap-down invites a violent bounce — floored at {floor:.1f}."
                )
                score = floor
            flags.append("CAPITULATION")

    # --- squeeze context (annotation only, never a buy reason) ---------------
    if sig.short_pct_float is not None and sig.short_pct_float >= 20.0:
        flags.append("HIGH_SHORT_INTEREST")
        rationale.append(
            f"{sig.short_pct_float:.0f}% of float short — moves here are mechanical "
            f"covering, which ends when covering ends. Context, not a thesis."
        )

    if sig.rvol >= 3.0:
        flags.append("VOLUME_SPIKE")
        rationale.append(f"Volume {sig.rvol:.1f}x its 20-day average.")

    if sig.mention_baseline_n < 3:
        flags.append("NO_BASELINE")
        rationale.append(
            "No mention history yet — velocity defaulted to neutral. Scores "
            "sharpen after a few days of scans."
        )

    score = _clamp(score, -10.0, 10.0)
    components["final"] = score
    return Result(sig.ticker, round(score, 2), label_for(score, flags), flags,
                  components, rationale, sig)


def rank(results: List[Result], min_abs_score: float = 2.0,
         top_n: int = 10) -> Dict[str, List[Result]]:
    """Split into actionable buckets. CONFLICT and CROWDED are surfaced
    separately rather than hidden — they are the interesting cases."""
    live = [r for r in results if r.label != "EXCLUDED"]
    conflicts = [r for r in live if "SIGNAL_CONFLICT" in r.flags]
    crowded = [r for r in live if "CROWDED" in r.flags and "SIGNAL_CONFLICT" not in r.flags]
    clean = [r for r in live if r not in conflicts and r not in crowded]

    longs = sorted([r for r in clean if r.score >= min_abs_score],
                   key=lambda r: -r.score)[:top_n]
    shorts = sorted([r for r in clean if r.score <= -min_abs_score],
                    key=lambda r: r.score)[:top_n]
    return {
        "long": longs,
        "short": shorts,
        "crowded": sorted(crowded, key=lambda r: -abs(r.score))[:top_n],
        "conflict": sorted(conflicts, key=lambda r: -abs(r.score))[:top_n],
        "excluded": [r for r in results if r.label == "EXCLUDED"],
    }
