"""Ticker extraction.

The single largest source of garbage in social sentiment tools. "I think the
CEO is an IDIOT and this DD is ATH tier IMO" contains four uppercase tokens and
zero tickers. CEO, DD, ATH and IMO are all real listed symbols.

Strategy, in order of trust:
  1. $CASHTAGS   — explicit, almost always right.
  2. Bare uppercase tokens — only if NOT in the stopword blacklist AND
     confirmed to be a real, liquid listed symbol (cached in SQLite).
"""
from __future__ import annotations

import re
from typing import Dict, Iterable, List, Optional, Set

_CASHTAG_RE = re.compile(r"\$([A-Za-z]{1,5})(?:\.[A-Za-z])?\b")
_BARE_RE = re.compile(r"\b([A-Z]{2,5})\b")

# Uppercase tokens that are real tickers but almost never MEANT as tickers in
# retail chatter. Every one of these was a false positive in practice.
STOPWORDS: Set[str] = {
    # finance jargon
    "CEO", "CFO", "COO", "CTO", "IPO", "ETF", "EPS", "PE", "PT", "DD", "TA",
    "ATH", "ATL", "EOD", "EOW", "EOY", "YTD", "QTD", "MTD", "AH", "PM",
    "FD", "FDS", "OTM", "ITM", "ATM", "IV", "DTE", "PL", "YOY", "QOQ",
    "ROI", "ROE", "EBIT", "CAGR", "AUM", "NAV", "SPAC", "REIT", "LEAP",
    "GDP", "CPI", "PPI", "PCE", "FOMC", "QE", "QT", "MOASS", "HFT",
    # agencies / orgs
    "SEC", "FDA", "FTC", "DOJ", "IRS", "FED", "ECB", "BOJ", "OPEC", "NATO",
    "NYSE", "AMEX", "OTC", "SPX", "NDX", "DJIA", "VIX", "FINRA", "CDC",
    "NASA", "DOD", "FAA", "EPA", "USDA", "WHO", "UN", "EU", "UK", "USA",
    "US", "CA", "NY", "LA", "SF", "DC", "CN", "JP", "DE", "FR", "IN",
    # chat / internet
    "IMO", "IMHO", "TLDR", "TLDR", "LOL", "LMAO", "WTF", "OMG", "FYI",
    "AMA", "ELI", "IIRC", "AFAIK", "YOLO", "FOMO", "HODL", "WSB", "OP",
    "EDIT", "TIL", "PSA", "NSFW", "IANAL", "AKA", "ETA", "ASAP", "RIP",
    "OK", "OKAY", "NO", "YES", "NOT", "AND", "OR", "IF", "IS", "IT",
    "BE", "DO", "GO", "SO", "TO", "UP", "ON", "IN", "AT", "BY", "MY",
    "ME", "WE", "HE", "AM", "AN", "AS", "OF", "THE", "FOR", "ARE",
    "BUT", "ALL", "CAN", "HAS", "HAD", "WAS", "ONE", "TWO", "NEW", "NOW",
    "OUT", "GET", "GOT", "HOW", "WHY", "WHO", "YOU", "SEE", "SAY", "TOO",
    "ANY", "MAY", "USE", "DAY", "MAN", "OLD", "BIG", "LOW", "HIGH",
    "BUY", "SELL", "HOLD", "PUT", "CALL", "PUTS", "GAIN", "LOSS", "BULL",
    "BEAR", "RED", "GREEN", "MOON", "PUMP", "DUMP", "LONG", "SHORT",
    "OPEN", "CLOSE", "STOP", "LIMIT", "CASH", "RISK", "FREE", "REAL",
    # months / days
    "JAN", "FEB", "MAR", "APR", "JUN", "JUL", "AUG", "SEP", "SEPT", "OCT",
    "NOV", "DEC", "MON", "TUE", "TUES", "WED", "THU", "THUR", "THURS",
    "FRI", "SAT", "SUN",
}

# Symbols that ARE commonly discussed and collide with stopwords. If a bare
# token is in this set we keep it even though it looks like a word.
ALLOW_BARE: Set[str] = {
    "GME", "AMC", "SPY", "QQQ", "IWM", "TSLA", "NVDA", "AAPL", "MSFT",
    "AMZN", "META", "GOOG", "GOOGL", "AMD", "INTC", "MU", "PLTR", "SOFI",
    "HOOD", "RKLB", "SNDK", "HTZ", "TTD", "COIN", "MSTR", "SMCI", "AVGO",
    "TSM", "ARM", "NBIS", "SOUN", "IONQ", "RGTI", "ASTS", "LUNR", "CRWV",
}


class TickerExtractor:
    def __init__(self, validator=None, store=None, extra_stopwords: Optional[Iterable[str]] = None):
        """
        validator: callable(symbol) -> dict|None. Returns market metadata if the
                   symbol is a real, tradable listing. Injected so this module
                   stays testable without network.
        store:     Store instance for caching validation results.
        """
        self.validator = validator
        self.store = store
        self.stopwords = set(STOPWORDS)
        if extra_stopwords:
            self.stopwords |= {s.upper() for s in extra_stopwords}
        self._session_cache: Dict[str, bool] = {}

    def _is_valid(self, symbol: str) -> bool:
        symbol = symbol.upper()
        if symbol in ALLOW_BARE:
            return True
        if symbol in self._session_cache:
            return self._session_cache[symbol]
        if self.store is not None:
            row = self.store.get_symbol(symbol)
            if row is not None:
                ok = bool(row["valid"])
                self._session_cache[symbol] = ok
                return ok
        if self.validator is None:
            # No way to check — refuse bare tokens rather than pollute results.
            self._session_cache[symbol] = False
            return False
        meta = self.validator(symbol)
        ok = meta is not None
        self._session_cache[symbol] = ok
        if self.store is not None:
            self.store.put_symbol(symbol, ok, meta)
        return ok

    def extract(self, text: str, validate_bare: bool = True) -> List[str]:
        """Return unique tickers found, cashtags first."""
        if not text:
            return []
        found: List[str] = []
        seen: Set[str] = set()

        for m in _CASHTAG_RE.finditer(text):
            sym = m.group(1).upper()
            if sym not in seen and sym not in {"USD", "EUR", "GBP"}:
                seen.add(sym)
                found.append(sym)

        for m in _BARE_RE.finditer(text):
            sym = m.group(1).upper()
            if sym in seen or sym in self.stopwords:
                continue
            if validate_bare and not self._is_valid(sym):
                continue
            seen.add(sym)
            found.append(sym)

        return found

    def count(self, texts: Iterable[str], validate_bare: bool = True) -> Dict[str, int]:
        """Mention counts across many texts. One mention per ticker per text —
        a post that says NVDA nine times is one person, not nine."""
        counts: Dict[str, int] = {}
        for t in texts:
            for sym in self.extract(t, validate_bare=validate_bare):
                counts[sym] = counts.get(sym, 0) + 1
        return counts
