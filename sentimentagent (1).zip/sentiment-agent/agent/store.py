"""SQLite persistence.

Two jobs:
  1. Mention history, so "chatter velocity" is measured against this ticker's
     OWN baseline instead of a guess. A stock that always gets 200 mentions is
     not spiking at 200; a stock that normally gets 3 absolutely is.
  2. A call journal, so you can grade the agent later. Every call is written
     down with the price at the time, and `review` scores them on forward
     returns. Without this you can never find out whether it works.
"""
from __future__ import annotations

import json
import sqlite3
import statistics
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS mentions (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    ts        REAL    NOT NULL,
    ticker    TEXT    NOT NULL,
    source    TEXT    NOT NULL,
    count     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_mentions_ticker_ts ON mentions(ticker, ts);

CREATE TABLE IF NOT EXISTS calls (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    ts           REAL    NOT NULL,
    ticker       TEXT    NOT NULL,
    label        TEXT    NOT NULL,
    score        REAL    NOT NULL,
    price        REAL,
    flags        TEXT,
    evidence     TEXT,
    -- filled in later by `review`
    reviewed_ts  REAL,
    fwd_price    REAL,
    fwd_return   REAL,
    correct      INTEGER
);
CREATE INDEX IF NOT EXISTS idx_calls_ts ON calls(ts);

CREATE TABLE IF NOT EXISTS symbol_cache (
    symbol   TEXT PRIMARY KEY,
    valid    INTEGER NOT NULL,
    checked  REAL    NOT NULL,
    meta     TEXT
);
"""


class Store:
    def __init__(self, path: str = "agent_state.db"):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()

    # ---------------- mentions ----------------

    def record_mentions(self, ticker: str, source: str, count: int,
                        ts: Optional[float] = None) -> None:
        self.conn.execute(
            "INSERT INTO mentions (ts, ticker, source, count) VALUES (?,?,?,?)",
            (ts if ts is not None else time.time(), ticker.upper(), source, count),
        )
        self.conn.commit()

    def mention_baseline(self, ticker: str, lookback_hours: float = 168.0,
                         now: Optional[float] = None) -> Dict[str, float]:
        """Mean/stdev of prior mention totals per scan for this ticker.

        Returns n=0 when we have no history — the caller must then fall back to
        a neutral velocity rather than inventing a spike out of nothing.
        """
        now = now if now is not None else time.time()
        cutoff = now - lookback_hours * 3600
        rows = self.conn.execute(
            """SELECT ts, SUM(count) AS total FROM mentions
               WHERE ticker = ? AND ts >= ? AND ts < ?
               GROUP BY CAST(ts AS INTEGER)
               ORDER BY ts""",
            (ticker.upper(), cutoff, now),
        ).fetchall()
        totals = [float(r["total"]) for r in rows]
        if not totals:
            return {"n": 0, "mean": 0.0, "stdev": 0.0}
        mean = statistics.fmean(totals)
        stdev = statistics.pstdev(totals) if len(totals) > 1 else 0.0
        return {"n": len(totals), "mean": mean, "stdev": stdev}

    # ---------------- calls ----------------

    def record_call(self, ticker: str, label: str, score: float,
                    price: Optional[float], flags: List[str],
                    evidence: Dict[str, Any],
                    ts: Optional[float] = None) -> int:
        cur = self.conn.execute(
            """INSERT INTO calls (ts, ticker, label, score, price, flags, evidence)
               VALUES (?,?,?,?,?,?,?)""",
            (
                ts if ts is not None else time.time(),
                ticker.upper(),
                label,
                float(score),
                price,
                json.dumps(flags),
                json.dumps(evidence, default=str),
            ),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def unreviewed_calls(self, older_than_hours: float = 24.0,
                         now: Optional[float] = None) -> List[sqlite3.Row]:
        now = now if now is not None else time.time()
        cutoff = now - older_than_hours * 3600
        return self.conn.execute(
            """SELECT * FROM calls
               WHERE reviewed_ts IS NULL AND ts <= ? AND price IS NOT NULL
               ORDER BY ts""",
            (cutoff,),
        ).fetchall()

    def settle_call(self, call_id: int, fwd_price: float,
                    now: Optional[float] = None) -> Dict[str, Any]:
        row = self.conn.execute(
            "SELECT * FROM calls WHERE id = ?", (call_id,)
        ).fetchone()
        if row is None or not row["price"]:
            return {}
        ret = (fwd_price - row["price"]) / row["price"] * 100.0
        # A directional call is "correct" if the move went the way it leaned.
        # NEUTRAL / flagged calls are graded but never counted as correct,
        # because they were not predictions.
        if row["score"] > 0:
            correct = 1 if ret > 0 else 0
        elif row["score"] < 0:
            correct = 1 if ret < 0 else 0
        else:
            correct = 0
        self.conn.execute(
            """UPDATE calls SET reviewed_ts=?, fwd_price=?, fwd_return=?, correct=?
               WHERE id=?""",
            (now if now is not None else time.time(), fwd_price, ret, correct, call_id),
        )
        self.conn.commit()
        return {"ticker": row["ticker"], "label": row["label"],
                "score": row["score"], "return_pct": ret, "correct": bool(correct)}

    def scorecard(self) -> Dict[str, Any]:
        """Honest performance summary of settled directional calls."""
        rows = self.conn.execute(
            """SELECT * FROM calls
               WHERE reviewed_ts IS NOT NULL AND score != 0"""
        ).fetchall()
        if not rows:
            return {"n": 0}
        # Signed return: shorts profit when price falls.
        signed = [
            (r["fwd_return"] if r["score"] > 0 else -r["fwd_return"]) for r in rows
        ]
        hits = sum(1 for r in rows if r["correct"])
        by_label: Dict[str, Dict[str, Any]] = {}
        for r in rows:
            b = by_label.setdefault(r["label"], {"n": 0, "hits": 0, "rets": []})
            b["n"] += 1
            b["hits"] += int(bool(r["correct"]))
            b["rets"].append(
                r["fwd_return"] if r["score"] > 0 else -r["fwd_return"]
            )
        for b in by_label.values():
            b["hit_rate"] = b["hits"] / b["n"] if b["n"] else 0.0
            b["avg_return"] = statistics.fmean(b["rets"]) if b["rets"] else 0.0
            b.pop("rets")
        return {
            "n": len(rows),
            "hit_rate": hits / len(rows),
            "avg_signed_return": statistics.fmean(signed),
            "median_signed_return": statistics.median(signed),
            "best": max(signed),
            "worst": min(signed),
            "by_label": by_label,
        }

    # ---------------- symbol cache ----------------

    def get_symbol(self, symbol: str) -> Optional[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM symbol_cache WHERE symbol = ?", (symbol.upper(),)
        ).fetchone()

    def put_symbol(self, symbol: str, valid: bool,
                   meta: Optional[Dict[str, Any]] = None) -> None:
        self.conn.execute(
            """INSERT INTO symbol_cache (symbol, valid, checked, meta)
               VALUES (?,?,?,?)
               ON CONFLICT(symbol) DO UPDATE SET
                 valid=excluded.valid, checked=excluded.checked, meta=excluded.meta""",
            (symbol.upper(), int(valid), time.time(), json.dumps(meta or {}, default=str)),
        )
        self.conn.commit()
