#!/usr/bin/env python3
"""Turn scan output into a phone-friendly site, and decide whether to notify.

Run after `run.py scan` in CI:

    python ci/publish.py --reports ./reports --site ./site

Produces:
  site/index.html        latest scan, mobile-first, plus an archive list
  site/scan-*.html       every scan kept (newest first, capped)
  site/last_notified.json   which tickers we have already pinged about
  signal.json            {"notify": bool, "title": ..., "body": ...}

The notify decision is deliberately conservative: a name only fires once while
it stays on the board. Re-alerting every hour for the same ticker trains you to
ignore the alerts, which defeats the point of having them.
"""
from __future__ import annotations

import argparse
import html
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

KEEP_SCANS = 60


def load_latest(reports: Path) -> Dict[str, Any] | None:
    files = sorted(reports.glob("scan-*.json"))
    if not files:
        return None
    return json.loads(files[-1].read_text(encoding="utf-8"))


def actionable(scan: Dict[str, Any], min_score: float) -> List[Dict[str, Any]]:
    """Calls worth waking someone up for.

    CROWDED and CONFLICT buckets are excluded on purpose — they are useful to
    read but they are explicitly the cases the guards distrust, so they should
    never generate a push.
    """
    out = []
    for bucket in ("long", "short"):
        for r in scan.get("buckets", {}).get(bucket, []):
            if abs(r.get("score", 0)) >= min_score:
                out.append(r)
    return sorted(out, key=lambda r: -abs(r["score"]))


def build_index(site: Path, latest: Dict[str, Any], scan_files: List[Path]) -> None:
    stamp = latest.get("generated_utc", "")
    try:
        stamp_h = datetime.fromisoformat(stamp).strftime("%b %d, %Y · %H:%M UTC")
    except Exception:
        stamp_h = stamp

    rows = []
    for f in scan_files[:KEEP_SCANS]:
        label = f.stem.replace("scan-", "")
        try:
            dt = datetime.strptime(label, "%Y%m%d-%H%M%S")
            label = dt.strftime("%b %d · %H:%M")
        except ValueError:
            pass
        rows.append(f'<li><a href="{html.escape(f.name)}">{html.escape(label)}</a></li>')

    latest_html = scan_files[0].name if scan_files else ""
    calls = actionable(latest, 0.1)
    if calls:
        summary = ", ".join(
            f"<b>{html.escape(c['ticker'])}</b> {c['score']:+.1f}" for c in calls[:6]
        )
    else:
        summary = "<span class='quiet'>Nothing cleared the threshold — " \
                  "most scans look like this.</span>"

    doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="dark light">
<title>Sentiment Agent</title><style>
:root{{--bg:#0e1116;--card:#161b22;--line:#2a323d;--text:#e6edf3;--dim:#8b98a5;
--faint:#5f6b78;--accent:#58a6ff}}
@media(prefers-color-scheme:light){{:root{{--bg:#f6f8fa;--card:#fff;--line:#d8dee4;
--text:#1f2328;--dim:#59636e;--faint:#818b96;--accent:#0969da}}}}
*{{box-sizing:border-box}}
body{{margin:0;padding:24px 16px 56px;background:var(--bg);color:var(--text);
font:16px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
max-width:680px;margin-inline:auto;-webkit-text-size-adjust:100%}}
h1{{font-size:22px;margin:0 0 4px;letter-spacing:-.01em}}
.stamp{{color:var(--faint);font-size:13px;margin-bottom:20px}}
.hero{{background:var(--card);border:1px solid var(--line);border-radius:12px;
padding:18px;margin-bottom:14px}}
.hero .label{{font-size:11px;text-transform:uppercase;letter-spacing:.09em;
color:var(--dim);font-weight:600;margin-bottom:8px}}
.hero .val{{font-size:17px;line-height:1.5}}
.quiet{{color:var(--dim)}}
a.btn{{display:block;text-align:center;background:var(--accent);color:#fff;
text-decoration:none;padding:14px;border-radius:10px;font-weight:600;
margin-bottom:24px}}
h2{{font-size:12px;text-transform:uppercase;letter-spacing:.09em;color:var(--dim);
margin:28px 0 10px;font-weight:600}}
ul{{list-style:none;padding:0;margin:0}}
li{{border-bottom:1px solid var(--line)}}
li a{{display:block;padding:13px 2px;color:var(--text);text-decoration:none;
font-variant-numeric:tabular-nums}}
li a:active{{color:var(--accent)}}
footer{{margin-top:32px;padding-top:16px;border-top:1px solid var(--line);
font-size:12px;color:var(--faint)}}
</style></head><body>
<h1>Sentiment Agent</h1>
<div class="stamp">Last scan {html.escape(stamp_h)}</div>
<div class="hero"><div class="label">Current signal</div>
<div class="val">{summary}</div></div>
<a class="btn" href="{html.escape(latest_html)}">Open latest report</a>
<h2>History</h2><ul>{''.join(rows)}</ul>
<footer>Research signal, not advice. Sentiment decays fast and is heavily
front-run. Scans run on a schedule; alerts fire only when a name clears the
score threshold, and only once while it stays on the board.</footer>
</body></html>"""
    (site / "index.html").write_text(doc, encoding="utf-8")


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--reports", default="./reports")
    p.add_argument("--site", default="./site")
    p.add_argument("--min-score", type=float,
                   default=float(os.environ.get("NOTIFY_MIN_SCORE", "5.0")))
    p.add_argument("--signal-out", default="signal.json")
    args = p.parse_args()

    reports, site = Path(args.reports), Path(args.site)
    site.mkdir(parents=True, exist_ok=True)

    latest = load_latest(reports)
    if latest is None:
        print("No scan JSON found — nothing to publish.")
        Path(args.signal_out).write_text(json.dumps({"notify": False}), encoding="utf-8")
        return 0

    for f in reports.glob("scan-*.html"):
        shutil.copy2(f, site / f.name)
    for f in reports.glob("scan-*.json"):
        shutil.copy2(f, site / f.name)

    scan_files = sorted(site.glob("scan-*.html"), reverse=True)
    for stale in scan_files[KEEP_SCANS:]:
        stale.unlink(missing_ok=True)
        site.joinpath(stale.name.replace(".html", ".json")).unlink(missing_ok=True)
    scan_files = sorted(site.glob("scan-*.html"), reverse=True)

    build_index(site, latest, scan_files)

    # ---- notify decision -------------------------------------------------
    calls = actionable(latest, args.min_score)
    state_path = site / "last_notified.json"
    try:
        previous = set(json.loads(state_path.read_text(encoding="utf-8")))
    except Exception:
        previous = set()

    current = {c["ticker"] for c in calls}
    fresh = [c for c in calls if c["ticker"] not in previous]

    # Keep a name "seen" only while it is still on the board, so it can alert
    # again if it drops off and later comes back.
    state_path.write_text(json.dumps(sorted(current)), encoding="utf-8")

    if not fresh:
        print(f"{len(calls)} call(s) above {args.min_score}, none new. No alert.")
        Path(args.signal_out).write_text(
            json.dumps({"notify": False, "count": len(calls)}), encoding="utf-8")
        return 0

    lines = []
    for c in fresh:
        m = c.get("market", {})
        flags = ", ".join(f for f in c.get("flags", []) if f != "NO_BASELINE")
        lines.append(
            f"### {c['ticker']} — {c['label']} ({c['score']:+.1f})\n\n"
            f"- price ${m.get('price') or 0:,.2f} · 1d {m.get('ret_1d', 0):+.1f}%"
            f" · 5d {m.get('ret_5d', 0):+.1f}% · rvol {m.get('rvol', 1):.1f}x\n"
            f"- flags: {flags or '—'}\n\n"
            + "\n".join(f"  - {r}" for r in c.get("rationale", []))
        )

    tickers = ", ".join(c["ticker"] for c in fresh)
    body = (
        f"Scan at {latest.get('generated_utc','')} flagged **{tickers}** "
        f"above the {args.min_score:+.1f} threshold.\n\n"
        + "\n\n".join(lines)
        + "\n\n---\n\nResearch signal, not advice. Sentiment decays fast and is "
          "heavily front-run — read the flags and the reasoning, not just the score."
    )
    signal = {
        "notify": True,
        "title": f"Signal: {tickers}",
        "body": body,
        "tickers": sorted(t for t in current),
        "count": len(fresh),
    }
    Path(args.signal_out).write_text(json.dumps(signal, indent=2), encoding="utf-8")
    print(f"ALERT: {tickers}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
